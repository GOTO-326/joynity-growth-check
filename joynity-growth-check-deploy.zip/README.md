# joynity Growth Check — Vercel公開ガイド（初回リリース）

成長発達チェックシステム / Version 6.0
このフォルダ一式で、Vercelに公開できます。プログラミング初心者でも進められるよう手順を分けて書いています。

---

## このアプリの特徴（Phase 1）

- スタッフが入力 → 保護者・本人・コーチ・スタッフ向けの4種のレポートを表示
- **PDF出力**：ブラウザの印刷機能でレポートをPDF保存・共有
- **CSV保存**：評価結果をローカルに保存（Excel/スプレッドシートで管理可能）
- **個人情報はクラウドに送信されません**（すべてブラウザ内で完結）
- ログイン・データベースは今回は不要（将来追加できる設計）

---

## A. ローカルで動かして確認する

パソコンに Node.js（v18以上）が入っていることが前提です。
未インストールなら https://nodejs.org/ から「LTS」版を入れてください。

```bash
# 1. このフォルダに移動
cd joynity-deploy

# 2. 必要なライブラリをインストール（初回のみ・数分かかります）
npm install

# 3. 開発サーバーを起動
npm run dev
```

→ 画面に出る `http://localhost:5173` をブラウザで開くと動作確認できます。
　止めるときは、ターミナルで `Ctrl + C`。

```bash
# 4. 本番用ビルドが通るか確認（公開前のチェック）
npm run build
```

→ エラーなく `dist` フォルダが作られれば成功です。

---

## B. Vercelで公開する（いちばん簡単な方法：GitHub経由）

### ステップ1：GitHubにコードを上げる

1. https://github.com/ でアカウント作成（無料）
2. 「New repository」で新しいリポジトリを作る（例：`joynity-growth-check`）
3. このフォルダの中身を、そのリポジトリにアップロード
   - 慣れていれば以下のコマンド：
   ```bash
   cd joynity-deploy
   git init
   git add .
   git commit -m "joynity Growth Check v6 初回リリース"
   git branch -M main
   git remote add origin https://github.com/あなたのID/joynity-growth-check.git
   git push -u origin main
   ```
   - コマンドが不安なら、GitHub Desktop（アプリ）でドラッグ&ドロップでもOK

### ステップ2：Vercelにつなぐ

1. https://vercel.com/ で「Continue with GitHub」でログイン（無料）
2. 「Add New...」→「Project」
3. さきほどのリポジトリを選んで「Import」
4. 設定はそのままでOK（Vercelが自動でViteを認識します）
   - Framework Preset: **Vite**（自動選択される）
   - Build Command: `npm run build`（自動）
   - Output Directory: `dist`（自動）
5. 「Deploy」を押す → 1〜2分で完了

### ステップ3：公開URLを取得

- 完了すると `https://joynity-growth-check.vercel.app` のようなURLが発行されます
- このURLをスタッフ・保護者・コーチに共有すれば、スマホ・iPad・PCどこからでも開けます

### 再デプロイ（修正を反映する）

GitHubにpushするだけで、Vercelが自動で再公開します。
```bash
git add .
git commit -m "修正内容"
git push
```

---

## C. PDF出力の使い方

1. レポート画面で、出力したいタブ（📄保護者 / 🏅コーチ など）を選ぶ
2. 「🖨 PDF出力（このタブを印刷）」ボタンを押す
3. ブラウザの印刷画面が開くので、「送信先」を **「PDFに保存」** にして保存
   - iPhone/iPad：共有ボタン →「プリント」→ 指でピンチアウト → 共有でPDF保存
   - これで保護者・コーチにPDFを送れます

※ アプリのメニューやボタンは印刷に含まれず、レポート部分だけがきれいに出力されます。

---

## D. 環境変数について

**Phase 1では設定不要です。** このアプリは外部サーバーを使わないため、APIキーや秘密情報はありません。
`.env.example` は将来Supabase等を追加するときのテンプレートとして残しています。

---

## E. 公開前チェックリスト

```
■ ローカルで npm run build がエラーなく通る
■ npm run dev で全6ステップが入力できる
■ レポートの5タブ（保護者/本人/コーチ/詳細/スタッフ）が表示される
■ PDF出力ボタンでレポートだけがきれいに印刷される
■ CSV保存ボタンでファイルがダウンロードされる
■ 「事前CSV読込」で既存サイトのCSVが読み込める
■ スマホで表示崩れがない（横スクロールが出ない）
■ iPadで表示崩れがない
■ PCで表示崩れがない
■ 「お子様さん」などの誤字がない
■ アプリ名が「joynity Growth Check」で統一されている
■ 断定的・不安を煽る表現がない
■ 公開URLを別端末（スマホ）から開いて動作する
```

---

## F. よくある質問

**Q. 入力したデータはどこに保存される？**
A. ブラウザの一時メモリのみです。ページを閉じると消えます。記録を残すには「CSVで保存」してください。クラウドには一切送信されません。

**Q. 複数のスタッフで同じデータを共有できる？**
A. Phase 1ではできません（端末内のみ）。共有はCSVまたはPDFで行ってください。将来Supabaseを追加すると共有・履歴管理が可能になります。

**Q. 既存の /intake/ ページの事前入力CSVは使える？**
A. はい。基本情報ステップの「📥 事前CSV読込」で読み込めます。
