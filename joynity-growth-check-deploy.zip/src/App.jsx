/**
 * joynity Growth Check  v7.0
 * 成長発達チェックシステム
 *
 * Design philosophy: "行動変容型レポート"
 *  評価結果 → 理解 → 納得 → 実践 → 変化 → 再評価
 *
 * Parent report structure:
 *  ① 総合評価サマリー（大丈夫？）
 *  ② 保護者のお悩み → 評価との関係 → 今育てたい能力 → 今月3つ → 期待できる変化
 *  ③ 成長ステージ + 見通し
 *  ④ 成長適応度スコア
 *  ⑤ 現在の症状
 *  ⑥ この時期に知っておきたい身体の変化
 *  ⑦ 強み
 *  ⑧ joynity導線（セミナー）
 *  ⑨ 次回評価
 */

import { useState, useMemo, useRef } from "react";

/* ─── DESIGN TOKENS ─── */
const C = {
  navy:"#1A2B3C", navyMid:"#2C4560",
  teal:"#1F9B85", tealLt:"#E3F5F1", tealDim:"#0D7A68",
  coral:"#D95F45", coralLt:"#FDEEE9",
  amber:"#C97D10", amberLt:"#FEF4E3",
  violet:"#6B5FC4", violetLt:"#F0EEF9",
  green:"#2A9D5C", greenLt:"#E8F5EE",
  blue:"#3B82C4", blueLt:"#EBF4FD",
  sand:"#F5F1EB", cream:"#FDFCFA",
  stone:"#7A8FA3", lineCol:"#E2D9CE",
  white:"#FFFFFF", dark:"#0E1A25",
};
const FF = {
  sans:"'Zen Kaku Gothic New','Noto Sans JP','Hiragino Sans',sans-serif",
  serif:"'Noto Serif JP','Hiragino Mincho ProN',serif",
};

/* ─── PRINT CSS ─── */
const PRINT_CSS = `
@media print {
  body * { visibility: hidden; }
  #print-area, #print-area * { visibility: visible; }
  #print-area { position: absolute; left: 0; top: 0; width: 100%; padding: 0; margin: 0; background: #fff; }
  .no-print { display: none !important; }
  @page { size: A4; margin: 10mm; }
}
`;

/* ─── PARENT CONCERNS ─── */
const CONCERN_OPTS = [
  { id:"height",    label:"身長が気になる",                      icon:"📏" },
  { id:"knee",      label:"膝の痛み（オスグッドなど）",           icon:"🦵" },
  { id:"back",      label:"腰の痛み",                            icon:"🔧" },
  { id:"hip",       label:"股関節・鼠径部の違和感",              icon:"⚙️" },
  { id:"achilles",  label:"アキレス腱・かかとの痛み",            icon:"👣" },
  { id:"posture",   label:"姿勢・内股傾向が気になる",            icon:"🧍" },
  { id:"core",      label:"体幹・フィジカル向上",                icon:"💪" },
  { id:"flex",      label:"身体の硬さが気になる",                icon:"🤸" },
  { id:"perf",      label:"パフォーマンスを伸ばしたい",          icon:"⚡" },
  { id:"nutrition", label:"栄養・食事・身長の伸び",              icon:"🍱" },
  { id:"sleep",     label:"睡眠・回復を改善したい",              icon:"🌙" },
  { id:"rehab",     label:"怪我後のリハビリ・再発予防",          icon:"🩹" },
  { id:"other",     label:"その他",                              icon:"💬" },
];

/* ─── CONCERN-TO-ACTION MAPPING ─── */
/* ─── CONCERN RESPONSE  (5-step: 状況→なぜ→今育てたい→今月3つ→期待できる変化) ─── */
const CONCERN_RESPONSE = {
  height: {
    headline:"今は身長の伸びをサポートする土台づくりに最適な時期です",
    stageNote:(stage)=>({
      peak:"現在はPeak PHV段階です。統計的に年間で最も身長が伸びやすい時期にあたる可能性があります。今この時期に睡眠・栄養・身体機能を整えることが、お子様本来の成長力を引き出す後押しになります。",
      pre:"現在はPre PHV段階です。これから成長が加速していく時期に備えて、睡眠・栄養・身体機能の土台を作る絶好のタイミングです。",
      post:"現在はPost PHV段階です。身長の急成長期は落ち着いてきましたが、体力・骨密度の充実はこれからです。引き続き睡眠・栄養を大切にしていきましょう。",
      hold:"成長ステージを確認中です。睡眠・栄養・身体機能を整えながら経過を見守っていきましょう。",
    }[stage]||"睡眠・栄養・身体機能を整えることが成長の後押しになります。"),
    why:"成長ホルモンは睡眠中（特に入眠後1〜3時間）に最も多く分泌されます。また、活動量に見合った栄養が取れていないと、成長へのエネルギーが不足する可能性があります。",
    abilities:["睡眠習慣","補食・栄養習慣","活動量管理"],
    actions:[
      {icon:"🌙", text:"毎晩22時までに就寝し、9時間以上の睡眠を目指す"},
      {icon:"🍙", text:"活動後30分以内におにぎり＋牛乳などの補食をとる"},
      {icon:"🍳", text:"朝食を毎日食べ、一日のエネルギーをしっかりチャージする"},
    ],
    whyActions:[
      "成長ホルモンは入眠後1〜3時間に多く分泌されます。早寝はその時間をしっかり確保することにつながります",
      "活動後の補食は、消費したエネルギーと栄養を補い、回復と成長をサポートします",
      "朝食は1日の代謝のスイッチを入れ、成長に必要な栄養素の摂取機会を増やします",
    ],
    benefit:"成長を支える生活習慣が整い、お子様本来の成長力が発揮されやすくなります",
    sport:"十分な睡眠と栄養は、競技パフォーマンスの土台にもなります",
    priority:[5,5,4],
    note:"※本サービスは最終身長を予測・保証するものではありません。お子様が本来もつ力を十分に発揮できるよう生活習慣を整えることを大切にしています。",
  },
  injury: {
    headline:"身体機能を整えることで、安心して活動できる土台を作りましょう",
    stageNote:(stage)=>stage==="peak"?"現在はPeak PHV段階です。骨が急速に伸びる時期は、筋肉・腱が骨の成長に追いつきにくくなります。この時期に柔軟性と体幹機能を育てることが、活動中の身体への負担を軽減します。":"身体機能を育てることで、より安心して活動しやすい状態が作られます。",
    why:"成長期は骨の成長に筋肉・腱が追いつきにくい時期です。特に柔軟性の低下と体幹の不安定さが重なると、膝・腰への負担が集中しやすくなります（MSI・PIM理論に基づく考え方）",
    abilities:["体幹安定性","股関節機能（ヒップヒンジ）","柔軟性"],
    actions:[
      {icon:"🦵", text:"太もも前面・もも裏のストレッチを毎日各3分続ける"},
      {icon:"💪", text:"デッドバグを週3回（10回×2セット）取り入れる"},
      {icon:"🌙", text:"十分な睡眠で毎日の身体の回復を助ける"},
    ],
    whyActions:[
      "柔軟性が整うと、骨の成長に対して筋肉・腱がより対応しやすくなります",
      "体幹が安定すると、活動中の身体のブレが減り、各部位への負担が分散します",
      "睡眠は身体の回復時間そのものです。日々の疲労をリセットする土台になります",
    ],
    benefit:"身体の使い方が整い、活動中の膝・腰への負担が軽減します",
    sport:"動作効率が高まり、より安心してスポーツを楽しめます",
    priority:[5,4,4],
    note:"",
  },
  perf: {
    headline:"身体機能の土台を作ることが、パフォーマンス向上への近道です",
    stageNote:(stage)=>stage==="peak"?"現在はPeak PHV段階です。この時期はパフォーマンスの「土台」を作る最良のタイミングです。柔軟性・体幹・股関節機能を育てることが、スピード・パワー・技術の伸びに直結します。":"身体機能の土台を整えることが、パフォーマンス向上につながります。",
    why:"成長期に身体の動かし方（動作の質）を高めることは、将来のパフォーマンスに大きく影響します。特に股関節機能と体幹安定性は、すべてのスポーツ動作の基盤になります（EXOS・DNS理論に基づく考え方）",
    abilities:["股関節機能（ヒップヒンジ）","体幹安定性","着地・切り返し動作"],
    actions:[
      {icon:"🔄", text:"ヒップヒンジの練習を週3回（1回5分）取り入れる"},
      {icon:"💪", text:"体幹エクササイズ（デッドバグ）を週3回続ける"},
      {icon:"🍙", text:"活動後の補食習慣で回復を早め、次の練習の質を上げる"},
    ],
    whyActions:[
      "股関節をうまく使えると、地面からの力を効率よく動きに変換できます",
      "体幹が安定すると、手足を大きく動かしても軸がぶれにくくなります",
      "活動後の補食で回復が早まると、次の練習の質が落ちにくくなります",
    ],
    benefit:"動作効率が高まり、同じ練習量でより多くの成果が得られます",
    sport:"ダッシュ・ジャンプ・切り返し・持久力すべてに良い影響が出ます",
    priority:[5,4,4],
    note:"",
  },
  posture: {
    headline:"姿勢は胸椎と体幹の機能から整えていきましょう",
    stageNote:()=>"姿勢の改善には、背中（胸椎）の動きと体幹のコントロール機能が大切です。成長期はこれらを育てるのに最適な時期です。",
    why:"姿勢が崩れる主な原因は「背中が硬い」「体幹が弱い」「呼吸が浅い」のいずれかにあることが多いです。これらを同時にアプローチすることが最も効果的です（DNS・MSI理論に基づく考え方）",
    abilities:["胸椎（背中）の動き","体幹安定性","呼吸機能"],
    actions:[
      {icon:"🔄", text:"胸椎回旋エクササイズを朝晩10回取り入れる"},
      {icon:"🌬️", text:"呼吸エクササイズ（お腹を意識した鼻呼吸）を毎日1分続ける"},
      {icon:"💪", text:"デッドバグを週3回（10回×2セット）取り入れる"},
    ],
    whyActions:[
      "背中の動きが整うと、自然と良い姿勢を保ちやすくなります",
      "呼吸が整うと体幹の内側から姿勢を支える力が働きやすくなります",
      "体幹が安定すると、座る・立つ・動くすべての姿勢の土台になります",
    ],
    benefit:"背骨の動きが整い、自然な姿勢が維持しやすくなります",
    sport:"姿勢が安定することで、動作の効率と持久力が高まります",
    priority:[4,4,3],
    note:"",
  },
  flex: {
    headline:"柔軟性は毎日の小さな積み重ねで着実に高まります",
    stageNote:(stage)=>stage==="peak"?"現在はPeak PHV段階です。骨が急速に伸びるため、筋肉・腱が相対的に硬くなりやすい時期です。毎日のストレッチが特に効果的です。":"成長期を通じて、柔軟性を継続的に維持することが大切です。",
    why:"成長期は骨が先に伸び、筋肉・腱が後から追いつく過程で硬さが生じます。毎日少しずつ取り組むことで、身体の動きやすさと成長の適応力が高まります",
    abilities:["もも裏の柔軟性","股関節の動き","太もも前面のケア"],
    actions:[
      {icon:"🤸", text:"もも裏のストレッチを毎日3分（お風呂上がりが最適）続ける"},
      {icon:"🔄", text:"股関節の回旋ストレッチを朝晩取り入れる"},
      {icon:"🧘", text:"活動後にセルフケアを週4回以上行う"},
    ],
    whyActions:[
      "もも裏の柔軟性は、骨盤の傾きや膝への負担に直結します",
      "股関節の動きが良くなると、歩く・走る・蹴る動作の可動域が広がります",
      "活動後のケアは、その日の疲労を翌日に持ち越さないために大切です",
    ],
    benefit:"動作がスムーズになり、活動後の疲れが取れやすくなります",
    sport:"あらゆるスポーツ動作の質と怪我への対応力が高まります",
    priority:[4,4,3],
    note:"",
  },
  nutrition: {
    headline:"成長を支える栄養の3本柱を整えましょう",
    stageNote:(stage)=>stage==="peak"?"現在はPeak PHV段階です。身体を大きくするためのエネルギーと、活動で使うエネルギーの両方が必要です。特にたんぱく質・カルシウム・鉄が重要です。":"成長期全般を通じて、栄養バランスの良い食事が成長と活動を支えます。",
    why:"活動量に見合った栄養が取れていないと、成長のためのエネルギーが不足する可能性があります（RED-Sと呼ばれる状態を避けることが大切）。練習後30分以内の補食が特に重要です",
    abilities:["補食習慣","朝食習慣","水分補給"],
    actions:[
      {icon:"🍙", text:"活動後30分以内に補食（炭水化物＋たんぱく質の組み合わせ）をとる"},
      {icon:"🥛", text:"毎日の食事に乳製品や小魚を取り入れ、カルシウムを補給する"},
      {icon:"🍳", text:"朝食を毎日食べ、一日のエネルギーをチャージする"},
    ],
    whyActions:[
      "活動後30分は栄養を取り込みやすい時間帯で、回復効率が高まります",
      "カルシウムは骨の材料そのもの。成長期は特に必要量が増えます",
      "朝食は1日のエネルギー代謝のスイッチを入れる役割があります",
    ],
    benefit:"回復が早まり、成長と活動の両方をしっかり支えられます",
    sport:"練習の質が上がり、試合での後半のスタミナにも好影響があります",
    priority:[5,4,4],
    note:"",
  },
  sleep: {
    headline:"睡眠の質と量を整えることが成長と回復の基盤になります",
    stageNote:(stage)=>stage==="peak"?"現在はPeak PHV段階です。成長ホルモンは睡眠中（特に入眠後1〜3時間）に集中して分泌されます。この時期の睡眠は特に重要です。":"睡眠は成長・回復・集中力のすべてに影響します。毎日の習慣として大切にしましょう。",
    why:"睡眠時間が短いと成長ホルモンの分泌が減少し、骨・筋肉の回復が追いつきにくくなります。また集中力の低下にも影響します",
    abilities:["睡眠習慣","就寝リズム","回復力"],
    actions:[
      {icon:"🌙", text:"就寝時間を決めて毎日8〜9時間（できれば9時間以上）を確保する"},
      {icon:"📵", text:"就寝1時間前はスマホ・ゲームを手放す（ブルーライトが眠りの質を下げる）"},
      {icon:"🧘", text:"就寝前に軽いストレッチで身体をほぐす"},
    ],
    whyActions:[
      "就寝時間が一定だと、深い睡眠に入りやすいリズムが作られます",
      "ブルーライトは脳を覚醒させ、寝つきと睡眠の質を下げてしまいます",
      "就寝前のストレッチは身体の緊張をゆるめ、入眠をスムーズにします",
    ],
    benefit:"成長ホルモンの分泌が高まり、身体の回復と成長が効率よく進みます",
    sport:"翌日の練習の質が上がり、集中力と判断速度の向上につながります",
    priority:[5,5,4],
    note:"",
  },
  focus: {
    headline:"集中力は睡眠・栄養・身体機能から支えられます",
    stageNote:()=>"集中力は睡眠の質・血糖値の安定・身体のコンディションと深く関わっています。生活習慣を整えることが集中力の土台になります。",
    why:"睡眠不十分・血糖値の乱れ・体幹の不安定さは、いずれも集中力の低下に直結します。呼吸機能を高めることも集中力維持に有効です（DNS理論に基づく考え方）",
    abilities:["睡眠習慣","補食習慣","呼吸機能"],
    actions:[
      {icon:"🌙", text:"毎晩8〜9時間の睡眠で脳と身体をしっかり休ませる"},
      {icon:"🍙", text:"活動前後に補食で血糖値を安定させる"},
      {icon:"🌬️", text:"呼吸エクササイズを1日1分取り入れる"},
    ],
    whyActions:[
      "睡眠は脳の疲労回復に直結し、翌日の集中力に影響します",
      "血糖値が安定すると、集中力の波が少なくなります",
      "呼吸が整うと自律神経が安定し、集中しやすい状態になります",
    ],
    benefit:"集中しやすい身体のコンディションが整います",
    sport:"後半まで集中力を維持でき、プレーの精度が高まります",
    priority:[5,4,3],
    note:"",
  },
  other: {
    headline:"今できることから、一歩ずつ始めていきましょう",
    stageNote:()=>"評価結果をもとに、今のお子様にとって最も大切な取り組みを3つに絞りました。",
    why:"身体機能・生活習慣・症状の評価を総合した結果、今最も効果的な取り組みを選びました",
    abilities:["睡眠習慣","身体機能の土台","回復習慣"],
    actions:[
      {icon:"🌙", text:"毎晩の睡眠時間を8〜9時間確保する"},
      {icon:"🍙", text:"活動後の補食を習慣にする"},
      {icon:"🧘", text:"週3回以上のセルフケアを続ける"},
    ],
    whyActions:[
      "睡眠は成長・回復・集中力すべての土台になります",
      "活動後の補食は、その日の疲労回復を助けます",
      "セルフケアの習慣は、身体の変化に早く気づくことにもつながります",
    ],
    benefit:"土台となる習慣が育ち、身体と成長のサポートにつながります",
    sport:"すべてのスポーツ動作の土台が整い、長期的なパフォーマンス向上につながります",
    priority:[5,4,3],
    note:"",
  },

  knee: {
    headline:"膝の痛みに関わる身体の使い方を整えましょう",
    stageNote:(stage)=>stage==="peak"?"現在はPeak PHV段階です。骨の成長に筋肉・腱が追いつきにくい時期のため、膝への繰り返し負荷が痛みにつながりやすくなっています。":"成長期は膝まわりへの負荷が集中しやすい時期です。",
    why:"膝の痛みの多くは「股関節をうまく使えない」「太もも前面が硬い」「体幹が不安定」のいずれかが背景にあります。これらを整えることで膝への負担が分散されます",
    abilities:["股関節機能（ヒップヒンジ）","太もも前面の柔軟性","体幹安定性"],
    actions:[
      {icon:"🔄",text:"ヒップヒンジ練習を週3回（1回5分）取り入れる"},
      {icon:"🦵",text:"太もも前面のストレッチを毎日3分（入浴後）続ける"},
      {icon:"📏",text:"活動量を急に増やさず、今の量を維持しながら様子をみる"},
    ],
    whyActions:[
      "股関節を使えるようになると、膝に集中していた負担が分散されます",
      "太もも前面の柔軟性が高まると、膝のお皿まわりへの引っ張りが和らぎます",
      "活動量を急に増やさないことで、膝への繰り返し負荷を抑えられます",
    ],
    benefit:"股関節が使えるようになると、膝への集中した負荷が分散されます",
    sport:"ジャンプ・ダッシュ・切り返し動作が安定し、膝の疲れが軽くなります",
    priority:[5,5,4],
    faq:[
      {q:"オスグッド病ですか？",a:"膝のお皿の下の骨（脛骨粗面）を押すと痛い場合はオスグッド病の可能性があります。成長期によくある症状ですが、担当スタッフに確認していただくことをおすすめします。"},
      {q:"練習は休むべきですか？",a:"痛みの程度によります。痛みが強い場合は量を減らし、無理に続けず担当スタッフに相談してください。"},
      {q:"ストレッチは効果がありますか？",a:"太もも前面ともも裏のストレッチは膝への負担軽減に有効です。毎日続けることが大切です。"},
    ],
    note:"",
  },
  back: {
    headline:"腰の痛みには呼吸・胸椎・体幹のサポートが効果的です",
    stageNote:(stage)=>stage==="peak"?"現在はPeak PHV段階です。骨の急成長期は腰椎（腰の骨）への負担が増えやすくなります。疲労骨折（腰椎分離症）への早めのケアが大切な時期です。":"腰の痛みには身体の使い方が関係していることが多く、丁寧にアプローチすることで改善しやすくなります。",
    why:"腰の痛みは「背中が硬い（胸椎の可動性低下）」「呼吸が浅い（体幹の不安定）」「股関節が硬い」のいずれかが原因に関係することが多く、これらを改善することで腰への負担が軽減します（MSI・DNS理論に基づく考え方）",
    abilities:["胸椎（背中）の動き","呼吸機能・体幹安定性","股関節の柔軟性"],
    actions:[
      {icon:"🔄",text:"胸椎回旋エクササイズ（四つ這いで上体をひねる）を朝晩10回行う"},
      {icon:"🌬️",text:"呼吸エクササイズ（お腹を意識した深呼吸）を毎日1分取り入れる"},
      {icon:"🤸",text:"股関節の前面ストレッチを毎日3分続ける"},
    ],
    whyActions:[
      "背中（胸椎）の動きが整うと、腰が代わりに動きすぎる必要が減ります",
      "深い呼吸は体幹の内側から腰を支える力を生み出します",
      "股関節の柔軟性が高まると、腰への負担が分散されます",
    ],
    benefit:"背中と体幹の連動性が高まり、腰への余分な負担が軽減します",
    sport:"体の回旋動作が改善し、キック・スプリント・方向転換の効率が上がります",
    priority:[5,5,4],
    faq:[
      {q:"腰椎分離症の可能性はありますか？",a:"成長期の腰痛で、特に反った時に痛い・片脚立ちで痛い場合は早めに医療機関を受診することをおすすめします。"},
      {q:"練習は続けて大丈夫ですか？",a:"痛みが続く・動くと痛い場合は活動量を減らし、担当スタッフに相談してください。"},
      {q:"何を鍛えれば腰痛が改善しますか？",a:"体幹を「鍛える」より、呼吸と胸椎の動きを「整える」ことの方が効果的です。"},
    ],
    note:"",
  },
  hip: {
    headline:"股関節まわりの痛みには動きの質の改善が効果的です",
    stageNote:(stage)=>stage==="peak"?"現在はPeak PHV段階です。骨盤・股関節まわりの成長部位に繰り返し負荷がかかりやすい時期です。":"股関節まわりの痛みは身体の動かし方と深く関係しています。",
    why:"股関節の痛みは「片脚での動作安定性の低下」「体幹のコントロール不足」「股関節まわりの柔軟性低下」が重なることで生じやすくなります",
    abilities:["片脚での安定性","体幹安定性","股関節の柔軟性"],
    actions:[
      {icon:"⚖️",text:"片脚立ちバランストレーニングを週3回（20秒×3）取り入れる"},
      {icon:"💪",text:"デッドバグを週3回（10回×2セット）取り入れる"},
      {icon:"🤸",text:"股関節の前面・外側のストレッチを毎日3分続ける"},
    ],
    whyActions:[
      "片脚での安定性が高まると、股関節への偏った負担が減ります",
      "体幹が安定すると、股関節まわりの筋肉に余分な力みが生じにくくなります",
      "股関節の柔軟性は、可動域全体のスムーズさにつながります",
    ],
    benefit:"片脚の安定性が高まり、股関節への余分な負担が軽減します",
    sport:"切り返し・ダッシュスタート・方向転換の動作が安定します",
    priority:[5,4,4],
    faq:[
      {q:"グロインペイン（鼠径部痛）ですか？",a:"鼠径部の痛みは複数の原因が考えられます。痛みが続く場合は医療機関への受診をおすすめします。"},
      {q:"インソールは必要ですか？",a:"内股傾向や脚長差がある場合はインソールが有効な場合があります。担当スタッフに相談してください。"},
    ],
    note:"",
  },
  achilles: {
    headline:"アキレス腱・かかとの痛みには柔軟性と活動量管理が重要です",
    stageNote:(stage)=>stage==="peak"||stage==="pre"?"現在は成長期です。かかとの骨の成長部位（骨端）は繰り返しの負荷に対して弱くなりやすい時期です。シーバー病（踵骨骨端症）が起こりやすい時期でもあります。":"アキレス腱まわりの痛みには柔軟性と身体の動かし方が関係しています。",
    why:"アキレス腱・かかとの痛みは「もも裏の硬さ」「足首の動きの制限」「急激な活動量の増加」が重なることで生じやすくなります",
    abilities:["もも裏・ふくらはぎの柔軟性","足首の動き","活動量管理"],
    actions:[
      {icon:"🤸",text:"ふくらはぎ・もも裏のストレッチを毎日3分（入浴後）続ける"},
      {icon:"📏",text:"活動量の急増を避け、週10%以内の増加ルールを守る"},
      {icon:"🧘",text:"活動後に足首・ふくらはぎのセルフケアを週4回以上行う"},
    ],
    whyActions:[
      "ふくらはぎ・もも裏の柔軟性が高まると、アキレス腱への引っ張りが和らぎます",
      "活動量の急増を避けることで、かかとの成長部位への繰り返し負荷を抑えられます",
      "活動後のケアは、その日の負荷をその日のうちにケアする習慣になります",
    ],
    benefit:"腱まわりの柔軟性が高まり、かかとへの繰り返し負荷が軽減します",
    sport:"蹴り出し・ランニング動作が安定し、疲れにくくなります",
    priority:[5,4,4],
    faq:[
      {q:"シーバー病ですか？",a:"かかとの骨の端を押すと痛い場合はシーバー病（踵骨骨端症）の可能性があります。成長期によくある症状です。担当スタッフに確認してください。"},
      {q:"練習を続けて大丈夫ですか？",a:"痛みが強い場合は活動量を減らし、ジャンプ・ダッシュを一時的に減らすことで症状が落ち着くことがあります。"},
    ],
    note:"",
  },
  core: {
    headline:"成長期に適した体幹づくりで競技力の土台を作りましょう",
    stageNote:(stage)=>stage==="peak"?"現在はPeak PHV段階です。この時期は筋力トレーニングより、体幹の「安定性」と「連動性」を育てることが最優先です。":"体幹の安定性は、すべてのスポーツ動作の基盤になります。",
    why:"体幹トレーニングは「筋肉を鍛える」ことより、「呼吸と身体をつなげて安定させる」ことを優先するのが成長期のポイントです（DNS・EXOS理論に基づく考え方）。高強度の筋トレよりもコントロール系エクササイズが効果的です",
    abilities:["呼吸と体幹の連動","片脚安定性","股関節機能"],
    actions:[
      {icon:"🌬️",text:"呼吸エクササイズ（お腹を膨らませて鼻から6秒で吐く）を毎日1分行う"},
      {icon:"💪",text:"デッドバグを週3回（10回×2セット）取り入れる"},
      {icon:"⚖️",text:"片脚立ちバランストレーニングを週3回（20秒×3）取り入れる"},
    ],
    whyActions:[
      "呼吸と体幹がつながると、姿勢を支える力が自然に働くようになります",
      "デッドバグは体幹を「固める」のではなく「安定して動かす」感覚を養います",
      "片脚での安定性は、走る・跳ぶ・止まるすべての動作の基礎になります",
    ],
    benefit:"姿勢が安定し、全身の動作効率が高まります",
    sport:"後半の集中力・スタミナが向上し、当たり負けしにくい身体づくりにつながります",
    priority:[5,4,4],
    faq:[
      {q:"成長期にウェイトトレーニングは良いですか？",a:"成長期は重いウェイトより、自体重での安定性・連動性を高めるトレーニングを優先するのがおすすめです。"},
      {q:"体幹が弱いと転びやすい？",a:"体幹の安定性が低いと、バランスを崩しやすくなります。コントロール系のエクササイズが効果的です。"},
      {q:"身長の成長に悪影響はありますか？",a:"適切な体重管理と段階的なトレーニングであれば成長への悪影響はありません。過度な高負荷トレーニングは避けてください。"},
    ],
    note:"",
  },
  rehab: {
    headline:"怪我後は段階的に身体機能を取り戻していきましょう",
    stageNote:()=>"怪我からの回復期は、無理をせず段階的に身体機能を再建することが大切です。再発予防のためには、怪我の原因となった動き方の改善も同時に取り組みましょう。",
    why:"怪我後に痛みが取れても、動きの癖や筋力のアンバランスが残っていると再発しやすくなります。段階的な機能回復と動作改善を組み合わせることが最も効果的です（PIM・EXOS理論に基づく考え方）",
    abilities:["段階的な機能回復","動作の質の改善","再発予防習慣"],
    actions:[
      {icon:"🩹",text:"痛みのない範囲でのセルフケアを毎日続ける"},
      {icon:"💪",text:"痛みのない範囲での体幹・バランスエクササイズから再開する"},
      {icon:"📏",text:"復帰後は活動量を段階的に増やし、急増を避ける"},
    ],
    whyActions:[
      "痛みのない範囲でのケアは、回復を妨げずに身体機能を保つために大切です",
      "段階的な再開は、復帰後の再発リスクを下げる最も確実な方法です",
      "活動量を急に戻さないことで、回復した組織への負担を抑えられます",
    ],
    benefit:"身体機能が段階的に回復し、再発リスクが下がります",
    sport:"より安全に、より良い動きでスポーツに復帰できます",
    priority:[5,4,4],
    faq:[
      {q:"いつ練習に復帰できますか？",a:"痛みがなくなっても、動作の質が戻るまでは徐々に段階を踏むことが大切です。担当スタッフと相談しながら進めてください。"},
      {q:"再発を防ぐためには何が大切ですか？",a:"怪我の原因となった動き方を改善することが最も重要です。痛みが取れた後も継続的なケアと評価をおすすめします。"},
    ],
    note:"",
  },
};

/* ─── STAGES ─── */
const STAGES = {
  pre:  { label:"Pre PHV",  jp:"成長準備期", icon:"🌱", color:"#5B8DD9",
          outlook:"身長が伸び始める前の大切な時期です。今のうちに柔軟性と基本動作の土台を作ることが、この先の成長を支えることにつながります。",
          stageMsg:"今は身体の土台づくりに最適な時期です。運動経験・基本動作・睡眠習慣を育てることで、これからの成長期をより安心して過ごせます。",
          focus:["運動経験","基本動作","睡眠習慣","柔軟性"] },
  peak: { label:"Peak PHV", jp:"急成長期",   icon:"🚀", color:C.coral,
          outlook:"身長が最も大きく伸びる時期に入っている可能性があります。骨の成長に筋肉や腱が追いつくまでに少し時間がかかることがあります。焦らず、身体のサインを大切に見守っていきましょう。",
          stageMsg:"現在は身長が最も伸びやすい時期です。骨の成長に対して筋肉や腱の適応が追いつきにくくなることがあります。睡眠・栄養・柔軟性・体幹機能を整えることが特に大切な時期です。",
          focus:["睡眠","栄養・補食","柔軟性","体幹機能","股関節機能"] },
  post: { label:"Post PHV", jp:"成長安定期", icon:"🌳", color:C.teal,
          outlook:"身長の伸びが落ち着いてきた時期です。体力・筋力づくりの効果が出やすく、パフォーマンス向上に取り組みやすい時期でもあります。",
          stageMsg:"成長が安定してきた今は、筋力・パワー・競技特異性を育てるのに最適な時期です。これまで培った土台の上に、さらなる可能性を積み上げていきましょう。",
          focus:["筋力","パワー","競技特異性","再発予防"] },
  hold: { label:"判定保留",  jp:"確認中",    icon:"⏳", color:C.stone,
          outlook:"現在、成長ステージを確認中です。引き続き定期的な評価で見守っていきます。",
          stageMsg:"成長ステージを確認中です。",
          focus:[] },
};

/* ─── STATUS ─── */
const STATUS_CFG = {
  safe: {
    label:"順調に成長をサポートできています", emoji:"🟢",
    icon:"○", color:C.teal, bg:C.tealLt,
    summary:"今のお子様の状態は良好です。成長と身体づくりが良いバランスで進んでいます。今の習慣を続けながら、さらに可能性を伸ばしていきましょう。",
    scoreNote:(gas)=>gas>=80?"身体機能と生活習慣がしっかり整っています。":"身体機能・生活習慣ともに良いペースで育っています。",
  },
  watch: {
    label:"今は身体づくりを意識したい時期です", emoji:"🟡",
    icon:"△", color:C.amber, bg:C.amberLt,
    summary:"今のお子様には伸びしろがたくさんあります。今月の取り組みを実践することで、より安心して活動しやすい身体づくりにつながります。",
    scoreNote:(gas)=>gas>=55?"多くの部分は順調です。いくつかの習慣を整えるとさらに良くなります。":"伸びしろが大きい時期です。少しずつ習慣を積み重ねていきましょう。",
  },
  caution: {
    label:"今後の成長のためにサポートを優先したい時期です", emoji:"🟠",
    icon:"◎", color:"#C97D10", bg:C.amberLt,
    summary:"今は身体づくりを丁寧に進めたい時期です。焦らず担当スタッフと一緒に、無理なく一歩ずつ取り組んでいきましょう。",
    scoreNote:(gas)=>"今は伸びしろがとても大きい時期です。取り組みを続けることで、確実に変化が生まれます。",
  },
};

/* ─── ABILITY MAP (function eval →育てたい能力) ─── */
/* ─── ABILITY MAP  (5-step: 現状→原因→今やること→期待できる変化→競技メリット) ─── */
const ABILITY_MAP = {
  hbd: {
    name:"ヒップヒンジ",
    icon:"🔄",
    status:"太もも前面の筋肉（大腿直筋）が硬くなっています",
    why:"骨が急速に伸びる時期は、筋肉が骨の伸びに追いつきにくくなります。太もも前面が硬いと膝や腰に負担が集中しやすくなります",
    ifNoChange:"このままでも活動は続けられますが、膝や腰の疲れが残りやすくなる可能性があります",
    action:{icon:"🔄",text:"ヒップヒンジ練習を週3回（1回5分）取り入れる"},
    benefit:"股関節をうまく使えるようになると、膝・腰への負担が分散されます",
    sport:"ジャンプ・ダッシュ・切り返しがより安定し、動きの効率が上がります",
    priority:5,
  },
  slr: {
    name:"もも裏の柔軟性",
    icon:"🤸",
    status:"もも裏の柔軟性に伸びしろがあります",
    why:"成長期は骨の成長に筋肉が追いつきにくい時期です。もも裏が硬いと骨盤が後傾しやすくなり、腰や膝の動きに影響することがあります",
    ifNoChange:"このままでも活動は可能ですが、成長に伴って腰や膝に疲れが出やすくなる可能性があります",
    action:{icon:"🤸",text:"もも裏ストレッチを毎日3分（入浴後がおすすめ）続ける"},
    benefit:"骨盤が安定し、腰・膝への余分な負担が軽くなります",
    sport:"走る・蹴る・跳ぶ動作がよりスムーズになります",
    priority:4,
  },
  trunk: {
    name:"体幹安定性",
    icon:"💪",
    status:"体幹を安定させる力に伸びしろがあります",
    why:"体幹が不安定だと、腕や脚を動かすたびに体がぶれやすくなります。成長期は特に体幹機能を育てる効果が高い時期です",
    ifNoChange:"このままでも動けますが、疲れが後半に出やすく、動きの精度にも影響が出ることがあります",
    action:{icon:"💪",text:"デッドバグを週3回（10回×2セット）取り入れる"},
    benefit:"全身の動作効率が高まり、疲れにくさにつながります",
    sport:"姿勢を維持したまま動けるようになり、後半のパフォーマンス低下が防げます",
    priority:4,
  },
  breath: {
    name:"呼吸機能",
    icon:"🌬️",
    status:"横隔膜（おなかの筋肉）をうまく使う練習が有効な状態です",
    why:"呼吸は体幹の安定に直結しています。横隔膜がうまく働くと、体の中心が安定し、集中力も維持しやすくなります（DNS理論に基づく考え方）",
    ifNoChange:"このままでも活動できますが、体幹の安定性や集中力の持続に影響が出ることがあります",
    action:{icon:"🌬️",text:"呼吸エクササイズ（鼻から吸ってお腹を膨らませ、ゆっくり6秒で吐く）を毎日1分行う"},
    benefit:"体幹が安定し、姿勢が整いやすくなります",
    sport:"後半の集中力維持、姿勢保持によるパフォーマンス安定につながります",
    priority:3,
  },
  thoracic: {
    name:"胸椎（背中）の動き",
    icon:"🔄",
    status:"背中（胸椎）の動きに改善の余地があります",
    why:"背中が硬いと、肩や腰が本来の動きを代わりに担うため、余計な負担がかかります。姿勢にも影響します（MSI理論に基づく考え方）",
    ifNoChange:"このままでも活動できますが、肩・腰の疲れや姿勢の崩れにつながりやすくなります",
    action:{icon:"🔄",text:"胸椎回旋エクササイズ（四つ這いで上体を左右にひねる）を朝晩各10回取り入れる"},
    benefit:"肩・腰への余分な負担が減り、動作がスムーズになります",
    sport:"投球・スイング・回旋動作の効率が高まります",
    priority:3,
  },
  balance: {
    name:"片脚での安定性",
    icon:"⚖️",
    status:"片脚で安定する力に伸びしろがあります",
    why:"片脚の安定性が低いと、切り返しや着地のたびに膝や足首に余分な負担がかかりやすくなります",
    ifNoChange:"このままでも活動できますが、着地・切り返し時に膝や足首の疲れが出やすくなる可能性があります",
    action:{icon:"⚖️",text:"片脚立ちバランストレーニングを週3回（20秒×3）取り入れる"},
    benefit:"着地・切り返し動作が安定し、膝・足首への負担が軽減します",
    sport:"方向転換や着地動作が安全で効率的になり、スポーツ動作全体の質が高まります",
    priority:4,
  },
  coord: {
    name:"着地・しゃがみ動作",
    icon:"🦵",
    status:"しゃがみ・着地動作の連動性に伸びしろがあります",
    why:"着地やしゃがみで膝が内側に入ったり体が前に倒れると、膝・腰に衝撃が集中しやすくなります（EXOS・PIMに基づく考え方）",
    ifNoChange:"このままでも活動できますが、ジャンプや着地の繰り返しで膝・腰への疲れが蓄積しやすくなります",
    action:{icon:"🦵",text:"スクワットの基本動作（膝とつま先の向きを揃えて）を週2回（10回×2セット）練習する"},
    benefit:"着地の衝撃が全身に分散され、膝・腰への負担が軽減します",
    sport:"ジャンプ・着地・ダッシュの動作効率が高まります",
    priority:4,
  },
};

/* ─── SCORING ENGINE ─── */
const NA_OPT = "非実施";
function ev_(val){ return !val||val===NA_OPT; }

function scoreBody(ev) {
  let romE=0,romP=0, flexE=0,flexP=0, trunkE=0,trunkP=0,
      coordE=0,coordP=0, strE=0,strP=0, balE=0,balP=0;

  // ROM
  if(!ev_( ev.thoracic_ok_str)){romP+=5; if(ev.thoracic_ok_str==="OK（10cm未満）")romE+=5;}
  if(!ev_(ev.squat_limit)){romP+=5; romE+=({制限なし:5,足関節制限:3,股関節制限:3,"足関節・股関節制限":1,関節協調性制限:2}[ev.squat_limit]||0);}

  // Flex
  const slrM={"90度":5,"反対側大腿〜膝蓋骨上縁以上":3,"膝未満":1};
  ["slr_r","slr_l"].forEach(k=>{ if(!ev_(ev[k])){ flexP+=5; flexE+=(slrM[ev[k]]||0); } });
  if(ev.hbd_r_ok===true||ev.hbd_r_ok===false){ flexP+=2.5; if(ev.hbd_r_ok===true)flexE+=2.5; }
  if(ev.hbd_l_ok===true||ev.hbd_l_ok===false){ flexP+=2.5; if(ev.hbd_l_ok===true)flexE+=2.5; }

  // Trunk
  ["pelvis_r","pelvis_l"].forEach(k=>{ if(!ev_(ev[k])){ trunkP+=2.5; if(ev[k]==="OK")trunkE+=2.5; } });
  if(!ev_(ev.pushup)){ trunkP+=5; trunkE+=({額レベルでできる:5,鎖骨レベルでできる:3,できない:0}[ev.pushup]||0); }
  if(!ev_(ev.breath)){ trunkP+=5; trunkE+=({呼気6秒できる:5,"4秒以上6秒未満":3,できない:0}[ev.breath]||0); }

  // Coord
  if(!ev_(ev.squat_coord)){ coordP+=5; coordE+=({できる:5,手が下がるができる:3,"臀部が膝下の高さまで下がるが制限あり":2,できない:0}[ev.squat_coord]||0); }
  const slsM={できる:5,"臀部が膝下まで下がる":3,"片脚しゃがみ込み姿勢はできる":2,できない:0};
  ["sls_r","sls_l"].forEach(k=>{ if(!ev_(ev[k])){ coordP+=5; coordE+=(slsM[ev[k]]||0); } });
  if(!ev_(ev.vertical_jump)){ coordP+=5; coordE+=({年齢平均以上:5,年齢平均:3,年齢平均未満:1}[ev.vertical_jump]||0); }

  // Strength
  ["strength_r","strength_l"].forEach(k=>{ if(!ev_(ev[k])){ strP+=5; strE+=(slsM[ev[k]]||0); } });
  ["step_r","step_l"].forEach(k=>{ if(!ev_(ev[k])){ strP+=2.5; if(ev[k]==="できる")strE+=2.5; } });

  // Balance
  const tanM={閉眼20秒:2.5,開眼20秒:1.5,できない:0};
  ["tandem_r","tandem_l"].forEach(k=>{ if(!ev_(ev[k])){ balP+=(tanM[ev[k]]!==undefined?2.5:0); balE+=(tanM[ev[k]]||0); } });
  const slbM={"30秒完全にできる":5,"骨盤後傾位でできる":4,"足が下がるができる":3,"15〜29秒良い姿勢でできる":2,"15〜29秒、骨盤後傾または足が下がる":1,できない:0};
  ["slb_r","slb_l"].forEach(k=>{ if(!ev_(ev[k])){ balP+=5; balE+=(slbM[ev[k]]||0); } });

  const bodyE=romE+flexE+trunkE+coordE+strE+balE;
  const bodyP=romP+flexP+trunkP+coordP+strP+balP;
  const norm = bodyP>0 ? Math.round((bodyE/bodyP)*70) : 0;

  return {
    norm, bodyE, bodyP,
    rom:  { pct:romP>0?Math.round(romE/romP*100):null },
    flex: { pct:flexP>0?Math.round(flexE/flexP*100):null,
            hbdPos: ev.hbd_r_ok===false||ev.hbd_l_ok===false,
            slrLow: ["反対側大腿〜膝蓋骨上縁以上","膝未満"].includes(ev.slr_r)||["反対側大腿〜膝蓋骨上縁以上","膝未満"].includes(ev.slr_l) },
    trunk:{ pct:trunkP>0?Math.round(trunkE/trunkP*100):null,
            pushupBad: ev.pushup==="できない"||ev.pushup==="鎖骨レベルでできる",
            breathBad: ev.breath==="できない"||ev.breath==="4秒以上6秒未満",
            thorBad:   ev.thoracic_ok_str==="NG（10cm以上）" },
    coord:{ pct:coordP>0?Math.round(coordE/coordP*100):null,
            sqBad: ev.squat_coord==="できない"||ev.squat_coord==="臀部が膝下の高さまで下がるが制限あり",
            slsBad:["できない","片脚しゃがみ込み姿勢はできる"].includes(ev.sls_r)||["できない","片脚しゃがみ込み姿勢はできる"].includes(ev.sls_l) },
    str:  { pct:strP>0?Math.round(strE/strP*100):null },
    bal:  { pct:balP>0?Math.round(balE/balP*100):null,
            balBad:["できない","15〜29秒、骨盤後傾または足が下がる"].includes(ev.slb_r)||["できない","15〜29秒、骨盤後傾または足が下がる"].includes(ev.slb_l) },
  };
}

function scoreHabit(h){
  const slp={"6時間未満":0,"6〜7時間":4,"7〜8時間":7,"8〜9時間":9,"9時間以上":10}[h.sleep]??5;
  const fr= {"なし":0,"月数回":2,"週1〜2回":5,"週3〜4回":8,"週5回以上":10};
  const hyd={"水分を持参していないことがある":0,"喉が渇いた時だけ飲む":4,"活動中に数回飲む":7,"活動中に定期的に飲む":9,"活動量に応じて意識して増やしている":10}[h.hydration]??5;
  return Math.min(30, Math.round(((slp+(fr[h.snack]??5)+(fr[h.selfcare]??5)+hyd+(fr[h.self_training]??5))/50)*30));
}

function calcGAS(bodyNorm, habitScore){ return Math.min(100, bodyNorm+habitScore); }

function calcStatus(gas, symptom, participation){
  if(participation==="医師へ相談推奨") return "caution";
  const impactHigh=["活動量を減らしている","休む必要がある"].includes(symptom.symptom_impact);
  if(impactHigh) return "caution";
  if(gas<45) return "caution";
  if(gas<65) return "watch";
  return "safe";
}

/* ─── ABILITY EXTRACTION ─── */
function extractAbilities(body, habit, stage){
  const list=[];
  if(body.flex?.slrLow || body.flex?.hbdPos) list.push("hbd");
  if(body.trunk?.breathBad) list.push("breath");
  if(body.trunk?.thorBad) list.push("thoracic");
  if(body.trunk?.pushupBad) list.push("trunk");
  if(body.coord?.sqBad) list.push("coord");
  if(body.coord?.slsBad) list.push("balance");
  if(stage==="peak"&&list.length<3) list.push("trunk");
  // habit based
  if(["なし","月数回"].includes(habit.snack) && !list.includes("trunk")) list.push("trunk");
  return [...new Set(list)].slice(0,3).map(k=>ABILITY_MAP[k]).filter(Boolean);
}

/* ─── TODOS ─── */
function genTodos(symptom, habit, body, stage, concerns=[]){
  const todos=[];
  const parts=(symptom.symptom_parts||[]).filter(p=>p!=="なし");
  const sleepBad=["6時間未満","6〜7時間","7〜8時間"].includes(habit.sleep);
  const snackBad=["なし","月数回"].includes(habit.snack);
  const hydBad  =["水分を持参していないことがある","喉が渇いた時だけ飲む"].includes(habit.hydration);

  // 痛み・違和感は「相談してください」だけで終わらせない：
  // ①なぜ起こる？ ②まず何をする？ ③改善しない場合は相談 の順で行動を提示
  if(parts.length>0){
    todos.push({p:10,icon:"🦵",text:"太もも前面・もも裏のストレッチを毎日各3分続けましょう",
      why:`${parts.join("・")}の違和感は、成長期に骨が筋肉より先に伸びることで起こりやすくなります。柔軟性を整えることが負担の軽減につながります`});
    todos.push({p:9,icon:"📏",text:"活動量を今の量から急に増やさず、様子をみながら進めましょう",
      why:"活動量の急増はオーバーユース（使いすぎ）につながりやすく、成長期特有の痛みの一因になります"});
    if(["違和感があっても続けている","どう対応すればよいかわからない"].includes(symptom.pain_response))
      todos.push({p:8,icon:"📋",text:`これらに取り組んでも${parts.join("・")}の違和感が続く場合は、担当スタッフにご相談ください`,
        why:"セルフケアで変化が見られない場合は、より詳しい評価とサポートにつなげることが大切です"});
  }

  if(stage==="peak") todos.push({p:8,icon:"📏",text:"活動量を急に増やさないようにしましょう（週10%以内が目安）",
    why:"急成長期は骨の伸びに筋肉・腱が追いつきにくく、活動量の急増が痛みの原因になりやすいためです"});
  if(sleepBad)  todos.push({p:9,icon:"🌙",text:"就寝時間を固定して、毎日8〜9時間以上の睡眠を目指しましょう",
    why:"成長ホルモンは睡眠中に多く分泌されます。十分な睡眠は骨や筋肉の成長・回復を支えます"});
  if(snackBad)  todos.push({p:7,icon:"🍙",text:"活動後30分以内におにぎり＋牛乳などの補食をとる習慣をつけましょう",
    why:"活動後の栄養補給は、筋肉の回復とエネルギーの再補充を助け、次の成長につながります"});
  if(hydBad)    todos.push({p:6,icon:"💧",text:"活動中は20〜30分ごとに水分を補給しましょう（喉が渇く前が目安）",
    why:"水分が不足すると疲労が蓄積しやすくなり、集中力やパフォーマンスにも影響します"});
  if(body.flex?.hbdPos||body.flex?.slrLow) todos.push({p:5,icon:"🦵",text:"太もも前面ともも裏のストレッチを毎日各3分続けましょう",
    why:"柔軟性を整えることで、膝や腰にかかる負担が分散されやすくなります"});
  if(body.trunk?.thorBad) todos.push({p:4,icon:"🔄",text:"胸椎回旋エクササイズを朝晩各10回取り入れましょう",
    why:"背中の動きが整うと、肩や腰が代わりに無理をする必要が減り、姿勢も安定します"});
  if(body.trunk?.breathBad) todos.push({p:4,icon:"🌬️",text:"呼吸エクササイズ（呼気6秒）を毎日1分練習しましょう",
    why:"呼吸が整うと体幹が安定し、姿勢の維持や集中力の持続につながります"});
  if(body.coord?.slsBad) todos.push({p:4,icon:"⚖️",text:"片脚立ちバランストレーニングを週3回（20秒×3）取り入れましょう",
    why:"片脚での安定性が高まると、着地や切り返し動作で膝・足首にかかる負担が軽減します"});
  if(concerns.includes("height")) todos.push({p:6,icon:"🍳",text:"朝食を毎日食べる習慣をつけましょう",
    why:"朝食は1日のエネルギー代謝のスイッチを入れ、成長に必要な栄養素の摂取機会を増やします"});

  // concern-driven override for top slot
  const topConcern = concerns[0];
  if(topConcern && CONCERN_RESPONSE[topConcern]){
    CONCERN_RESPONSE[topConcern].actions.forEach((a,i)=>todos.push({p:12-i, why:CONCERN_RESPONSE[topConcern].whyActions?.[i], ...a}));
  }

  return todos.sort((a,b)=>b.p-a.p).filter((t,i,arr)=>arr.findIndex(x=>x.text===t.text)===i).slice(0,3);
}

/* ─── EXPECTED CHANGES — generated from evaluation results ─── */
function genExpectedChanges(symptom, habit, body, stage, concerns=[]){
  const out=[];
  const parts=(symptom.symptom_parts||[]).filter(p=>p!=="なし");

  if(parts.includes("膝前面")) out.push("膝への負担軽減");
  if(parts.includes("腰")) out.push("腰への負担軽減");
  if(parts.includes("股関節")) out.push("股関節の動きやすさ向上");
  if(parts.includes("踵")) out.push("かかとへの負担軽減");
  if(body.coord?.pct!==null && (body.coord?.pct??100)<70) out.push("ジャンプ・着地動作の改善");
  if(body.flex?.slrLow||body.flex?.hbdPos) out.push("ダッシュ・キック動作の改善");
  if(body.trunk?.pct!==null && (body.trunk?.pct??100)<70) out.push("姿勢の安定");
  if(["6時間未満","6〜7時間","7〜8時間"].includes(habit.sleep)) out.push("疲れにくい身体づくり");
  if(stage==="peak") out.push("成長期の痛みの予防");
  if(["なし","月数回"].includes(habit.snack)) out.push("回復力の向上");
  if(concerns.includes("perf")||concerns.includes("core")) out.push("パフォーマンス向上");

  // ensure a healthy minimum even when everything looks good
  if(out.length<3){
    ["怪我予防","身体づくりの土台強化","成長への適応力アップ"].forEach(d=>{ if(!out.includes(d)) out.push(d); });
  }
  return [...new Set(out)].slice(0,6);
}

/* ─── STRENGTHS ─── */
function detectStrengths(body, habit, symptom){
  const out=[];
  const _ev0=body._ev||{};
  const slbGood=["30秒完全にできる","骨盤後傾位でできる"].includes(_ev0.slb_r)&&["30秒完全にできる","骨盤後傾位でできる"].includes(_ev0.slb_l);
  if(slbGood) out.push({icon:"⚖️",label:"バランス能力が高い水準です",detail:"片脚での安定した動作ができています"});
  if(_ev0.pushup==="額レベルでできる") out.push({icon:"💪",label:"体幹機能が高い",detail:"上半身を安定させる力が十分に備わっています"});
  if(_ev0.breath==="呼気6秒できる") out.push({icon:"🌬️",label:"呼吸コントロールが良好",detail:"横隔膜をうまく使えています"});
  if(_ev0.thoracic_ok_str==="OK（10cm未満）") out.push({icon:"🔄",label:"背中（胸椎）の動きが良好",detail:"上半身の回旋がスムーズです"});
  if(["週3〜4回","週5回以上"].includes(habit.snack)) out.push({icon:"🍙",label:"活動後の補食習慣あり",detail:"回復のための栄養補給ができています"});
  if(["8〜9時間","9時間以上"].includes(habit.sleep)) out.push({icon:"🌙",label:"十分な睡眠が確保できています",detail:"成長ホルモンが分泌される良質な睡眠がとれています"});
  if((symptom.symptom_parts||[]).every(p=>p==="なし")) out.push({icon:"✨",label:"現時点で違和感なし",detail:"気になる症状が確認されていません"});
  if(["週3〜4回","週5回以上"].includes(habit.self_training)) out.push({icon:"⚡",label:"自分から取り組む習慣あり",detail:"主体的な練習への意欲が見られます"});
  return out.slice(0,3);
}

/* ─── ATHLETE TITLE ─── */
function genTitle(body, habit){
  const _evT=body._ev||{};
  if(_evT.pushup==="額レベルでできる"&&_evT.breath==="呼気6秒できる") return{title:"体幹マスター",icon:"🏆",color:C.teal};
  if(["30秒完全にできる"].includes(_evT.slb_r)) return{title:"バランスキング",icon:"⚡",color:C.violet};
  if(_evT.slr_r==="90度"&&_evT.slr_l==="90度") return{title:"柔軟性エース",icon:"🌟",color:C.amber};
  if(["8〜9時間","9時間以上"].includes(habit.sleep)) return{title:"回復チャンピオン",icon:"🌙",color:C.blue};
  if(["週3〜4回","週5回以上"].includes(habit.snack)) return{title:"栄養管理マスター",icon:"🍙",color:C.green};
  return{title:"成長チャレンジャー",icon:"💪",color:C.coral};
}

/* ─── DOCTOR DRAFT ─── */
function genDraft(doctor, body, symptom, habit){
  const stage=doctor.stage||"peak";
  const stageL={pre:"成長準備期",peak:"急成長期",post:"成長安定期",hold:"判定保留"}[stage];
  const parts=(symptom.symptom_parts||[]).filter(p=>p!=="なし");
  const finds=[];
  if(body.flex?.hbdPos) finds.push("大腿前面の柔軟性に伸びしろ");
  if(body.flex?.slrLow) finds.push("もも裏の柔軟性に伸びしろ");
  if(body.trunk?.pushupBad) finds.push("体幹機能に伸びしろ");
  if(["6時間未満","6〜7時間"].includes(habit.sleep)) finds.push("睡眠を整える余地");
  if(["なし","月数回"].includes(habit.snack)) finds.push("活動後の栄養補給を高める余地");
  if(parts.length>0) finds.push(`${parts.join("・")}への継続的なサポートが有用`);
  let d=`${stageL}にあり、`;
  d+=finds.length>0?finds.join("・")+"がみられます。":"現時点で特に大きな変化はみられません。";
  if(stage==="peak") d+=" 急成長期のため、活動量の急増を避けることを推奨します。";
  d+=" 睡眠・栄養を含めた生活習慣の整備と定期的な評価の継続をお勧めします。";
  return d;
}

/* ─── CSV ─── */
function parseIntakeCSV(text){
  const out={};
  for(const line of text.split("\n").map(l=>l.trim()).filter(Boolean)){
    const [k,...rest]=line.split(",");
    out[k?.trim()]=rest.join(",").replace(/^"|"$/g,"").trim();
  }
  return out;
}
function exportCSV(all){
  const flat={...all.basic,...all.symptom,...all.habit,...all.ev,...all.doctor};
  const rows=Object.entries(flat).map(([k,v])=>`${k},"${Array.isArray(v)?v.join("|"):v||""}"`);
  rows.push(`gas,"${all.scores?.gas||0}"`,`status,"${all.scores?.status||""}"`,`export_date,"${new Date().toISOString().slice(0,10)}"`);
  return rows.join("\n");
}

/* ─── UI PRIMITIVES ─── */
function Pill({children,active,color=C.teal,bg=C.tealLt,onClick,sm}){
  return <button onClick={onClick} style={{padding:sm?"5px 10px":"8px 15px",borderRadius:24,border:`1.5px solid ${active?color:C.lineCol}`,background:active?bg:C.cream,color:active?color:C.stone,fontSize:sm?11:13,fontWeight:active?700:400,fontFamily:FF.sans,cursor:"pointer",transition:"all .15s"}}>{children}</button>;
}
function PG({opts,val,onChange,color=C.teal,bg=C.tealLt,multi,sm}){
  const isA=o=>multi?(Array.isArray(val)&&val.includes(o)):val===o;
  const handle=o=>{
    if(!multi){onChange(o);return;}
    const arr=Array.isArray(val)?[...val]:[];
    if(o==="なし"){onChange(["なし"]);return;}
    const next=arr.filter(x=>x!=="なし");
    onChange(next.includes(o)?next.filter(x=>x!==o)||["なし"]:[...next,o]);
  };
  return <div style={{display:"flex",flexWrap:"wrap",gap:8}}>{opts.map(o=><Pill key={o} active={isA(o)} color={color} bg={bg} onClick={()=>handle(o)} sm={sm}>{o}</Pill>)}</div>;
}
function FR({label,hint,children,tight}){
  return <div style={{marginBottom:tight?12:20}}><div style={{fontSize:12,fontWeight:700,color:C.navy,marginBottom:hint?2:7}}>{label}</div>{hint&&<div style={{fontSize:11,color:C.stone,marginBottom:7}}>{hint}</div>}{children}</div>;
}
function Card({children,style,accent}){
  return <div style={{background:C.white,borderRadius:16,padding:"18px 20px",marginBottom:12,boxShadow:"0 2px 20px rgba(26,43,60,.07)",border:`1px solid ${C.lineCol}`,borderLeft:accent?`4px solid ${accent}`:undefined,...style}}>{children}</div>;
}
function ST({children,color=C.teal}){
  return <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:14}}><div style={{width:4,height:18,borderRadius:2,background:color}}/><div style={{fontSize:14,fontWeight:800,color:C.navy,fontFamily:FF.sans}}>{children}</div></div>;
}
function Check({label,val,onChange}){
  return <label style={{display:"flex",alignItems:"center",gap:9,cursor:"pointer",marginBottom:5}}><div onClick={()=>onChange(!val)} style={{width:20,height:20,borderRadius:5,border:`2px solid ${val?C.teal:C.lineCol}`,background:val?C.teal:C.cream,display:"flex",alignItems:"center",justifyContent:"center",transition:"all .15s",flexShrink:0}}>{val&&<span style={{color:C.white,fontSize:13}}>✓</span>}</div><span style={{fontSize:13,color:val?C.navy:C.stone}}>{label}</span></label>;
}

function ScoreRing({score,size=80}){
  const r=30,circ=2*Math.PI*r,fill=circ*(score/100);
  const col=score>=70?C.teal:score>=50?C.amber:C.coral;
  return(<svg width={size} height={size} viewBox="0 0 80 80">
    <circle cx="40" cy="40" r={r} fill="none" stroke={C.lineCol} strokeWidth="7"/>
    <circle cx="40" cy="40" r={r} fill="none" stroke={col} strokeWidth="7"
      strokeDasharray={`${fill} ${circ}`} strokeLinecap="round" transform="rotate(-90 40 40)"/>
    <text x="40" y="44" textAnchor="middle" fontSize="16" fontWeight="800" fill={col} fontFamily={FF.serif}>{score}</text>
  </svg>);
}

function GrowthTimeline({stage}){
  const list=[{key:"pre",icon:"🌱",label:"成長準備期",sub:"Pre PHV"},{key:"peak",icon:"🚀",label:"急成長期",sub:"Peak PHV"},{key:"post",icon:"🌳",label:"成長安定期",sub:"Post PHV"}];
  const cur=list.findIndex(s=>s.key===stage);
  return(<div style={{padding:"12px 0 6px"}}>
    <div style={{fontSize:11,fontWeight:700,color:C.stone,letterSpacing:".1em",marginBottom:12,textAlign:"center"}}>成長ステージ</div>
    <div style={{display:"flex",alignItems:"flex-start",justifyContent:"center"}}>
      {list.map((s,i)=>{const active=s.key===stage,passed=cur>i;return(<div key={s.key} style={{display:"flex",alignItems:"center",flex:1}}>
        <div style={{flex:1,textAlign:"center"}}>
          <div style={{width:48,height:48,borderRadius:"50%",margin:"0 auto 8px",background:active?C.coral:passed?C.teal:C.lineCol,display:"flex",alignItems:"center",justifyContent:"center",fontSize:20,boxShadow:active?`0 0 0 4px ${C.coral}33`:passed?`0 0 0 3px ${C.teal}33`:"none"}}>{s.icon}</div>
          <div style={{fontSize:active?12:10,fontWeight:active?800:400,color:active?C.coral:passed?C.teal:C.stone}}>{s.label}</div>
          <div style={{fontSize:9,color:active?C.coral:C.stone,marginTop:1}}>{s.sub}</div>
          {active&&<div style={{marginTop:5,background:C.coral,color:C.white,borderRadius:10,padding:"2px 9px",fontSize:9,fontWeight:800,display:"inline-block"}}>現在地</div>}
        </div>
        {i<2&&<div style={{width:24,height:3,background:cur>i?C.teal:C.lineCol,borderRadius:2,flexShrink:0,marginTop:-20}}/>}
      </div>);})}
    </div>
  </div>);
}

function Radar({scores,labels,size=220}){
  const cx=size/2,cy=size/2,r=size*.32,n=labels.length;
  const pt=(i,rv)=>{const a=(Math.PI*2*i)/n-Math.PI/2;return[cx+rv*Math.cos(a),cy+rv*Math.sin(a)];};
  const vals=scores.map(s=>s??50);
  const path=vals.map((s,i)=>pt(i,(s/100)*r)).map((p,i)=>`${i?"L":"M"}${p[0].toFixed(1)},${p[1].toFixed(1)}`).join("")+"Z";
  return(<svg viewBox={`0 0 ${size} ${size}`} style={{width:"100%",maxWidth:size}}>
    {[.25,.5,.75,1].map(lv=>{const d=Array.from({length:n},(_,i)=>pt(i,r*lv)).map((p,i)=>`${i?"L":"M"}${p[0].toFixed(1)},${p[1].toFixed(1)}`).join("")+"Z";return<path key={lv} d={d} fill="none" stroke={lv===1?C.lineCol+"cc":C.lineCol+"55"} strokeWidth={lv===1?1.5:.8}/>;}) }
    {Array.from({length:n},(_,i)=>{const[x,y]=pt(i,r);return<line key={i} x1={cx} y1={cy} x2={x} y2={y} stroke={C.lineCol} strokeWidth=".8"/>;}) }
    <path d={path} fill={`${C.teal}28`} stroke={C.teal} strokeWidth="2.5" strokeLinejoin="round"/>
    {vals.map((s,i)=>{const[x,y]=pt(i,(s/100)*r);return<circle key={i} cx={x} cy={y} r="4" fill={C.teal} stroke={C.white} strokeWidth="1.5"/>;}) }
    {labels.map((lb,i)=>{const[x,y]=pt(i,r+19);return<text key={i} x={x} y={y} textAnchor="middle" dominantBaseline="middle" fontSize="9" fill={C.navy} fontFamily={FF.sans}>{lb}</text>;})}
  </svg>);
}

/* ══════════════════════════════════════════════
   REPORT: PARENT  — 行動変容ロードマップ
══════════════════════════════════════════════ */
function ParentReport({all}){
  const {basic={},symptom={},habit={},doctor={},scores={},body={}} = all;
  const stage = doctor.stage||"peak";
  const stageInfo = STAGES[stage]||STAGES.peak;
  const st = STATUS_CFG[scores.status||"watch"];
  const gas = scores.gas||0;
  const hasPain = (symptom.symptom_parts||[]).some(p=>p!=="なし");
  const concerns = basic.concerns||[];
  const topConcern = concerns[0];
  const concernCfg = topConcern ? CONCERN_RESPONSE[topConcern] : null;
  const abilities = extractAbilities(body, habit, stage);
  const todos = genTodos(symptom, habit, body, stage, concerns);
  const expectedChanges = genExpectedChanges(symptom, habit, body, stage, concerns);
  const strengths = detectStrengths(body, habit, symptom);
  const name = basic.name||"お子様";
  const partColor = {通常参加可能:C.teal,"状況に応じて調整":C.amber,"医師へ相談推奨":C.coral}[doctor.participation]||C.stone;
  const partMark  = {通常参加可能:"○","状況に応じて調整":"△","医師へ相談推奨":"□"}[doctor.participation]||"—";

  return(
    <div style={{fontFamily:FF.sans,maxWidth:700,margin:"0 auto"}}>
      {/* Cover */}
      <div style={{background:`linear-gradient(150deg,${C.dark} 0%,${C.navyMid} 100%)`,borderRadius:"18px 18px 0 0",padding:"28px 28px 22px",overflow:"hidden",position:"relative"}}>
        <div style={{position:"absolute",right:-40,top:-40,width:180,height:180,borderRadius:"50%",background:"rgba(255,255,255,.03)"}}/>
        <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:14}}>
          <div style={{width:30,height:30,borderRadius:8,background:C.teal,display:"flex",alignItems:"center",justifyContent:"center",fontSize:14}}>📊</div>
          <div>
            <div style={{fontSize:12,fontWeight:800,color:C.white,fontFamily:FF.serif}}>joynity Growth Check</div>
            <div style={{fontSize:9,color:"rgba(255,255,255,.4)"}}>成長発達チェックシステム</div>
          </div>
        </div>
        <div style={{fontSize:11,color:`${C.teal}cc`,fontWeight:600,letterSpacing:".06em",marginBottom:8}}>成長を見える化し、未来の可能性を育てる</div>
        <div style={{fontSize:22,fontWeight:900,color:C.white,fontFamily:FF.serif,lineHeight:1.3,marginBottom:6}}>
          {name}の成長サポートレポート
        </div>
        {topConcern&&concernCfg&&(
          <div style={{display:"inline-flex",alignItems:"center",gap:6,background:"rgba(255,255,255,.12)",borderRadius:8,padding:"4px 12px",marginBottom:4}}>
            <span style={{fontSize:14}}>{CONCERN_OPTS.find(c=>c.id===topConcern)?.icon}</span>
            <span style={{fontSize:12,color:"rgba(255,255,255,.8)"}}>今回のお悩み：{CONCERN_OPTS.find(c=>c.id===topConcern)?.label}</span>
          </div>
        )}
        <div style={{fontSize:11,color:"rgba(255,255,255,.35)",marginTop:6}}>評価日：{basic.eval_date||"—"} ／ 担当：{basic.trainer||"—"}</div>
      </div>

      {/* ① 総合評価サマリー — 大丈夫？ */}
      <div style={{background:st.bg,padding:"20px 24px",borderBottom:`1px solid ${C.lineCol}`}}>
        <div style={{fontSize:11,fontWeight:700,color:st.color,letterSpacing:".12em",marginBottom:10}}>① うちの子は大丈夫？</div>
        {/* emoji + label — one glance reassurance */}
        <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:12,padding:"12px 16px",background:"rgba(255,255,255,.65)",borderRadius:12}}>
          <span style={{fontSize:32,lineHeight:1}}>{st.emoji}</span>
          <div style={{flex:1}}>
            <div style={{fontSize:15,fontWeight:800,color:st.color,fontFamily:FF.serif,lineHeight:1.3}}>{st.label}</div>
          </div>
          <div style={{textAlign:"center"}}>
            <ScoreRing score={gas} size={64}/>
            <div style={{fontSize:9,color:C.stone,marginTop:2}}>成長適応度</div>
          </div>
        </div>
        {/* summary */}
        <div style={{fontSize:13,color:C.navy,lineHeight:1.8,marginBottom:8}}>{st.summary}</div>
        {/* score meaning — positive frame */}
        <div style={{fontSize:12,color:st.color,fontWeight:600,padding:"6px 12px",background:"rgba(255,255,255,.5)",borderRadius:8,lineHeight:1.5}}>{st.scoreNote(gas)}</div>
      </div>

      <div style={{background:C.sand,padding:"18px 18px 24px",borderRadius:"0 0 18px 18px"}}>

        {/* ② お悩みに対する個別ロードマップ */}
        {concernCfg&&(
          <Card accent={C.violet} style={{paddingBottom:20}}>
            {/* ヘッダー */}
            <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:12}}>
              <span style={{fontSize:22}}>{CONCERN_OPTS.find(c=>c.id===topConcern)?.icon}</span>
              <div>
                <div style={{fontSize:10,color:C.violet,fontWeight:700,letterSpacing:".1em"}}>{CONCERN_OPTS.find(c=>c.id===topConcern)?.label} へのサポートロードマップ</div>
                <div style={{fontSize:15,fontWeight:800,color:C.navy,lineHeight:1.4,marginTop:2}}>{concernCfg.headline}</div>
              </div>
            </div>
            {/* ステージ連動メッセージ */}
            <div style={{padding:"12px 14px",background:C.violetLt,borderRadius:10,marginBottom:14,border:`1px solid ${C.violet}33`}}>
              <div style={{fontSize:10,fontWeight:700,color:C.violet,marginBottom:4}}>📍 今の成長ステージと{CONCERN_OPTS.find(c=>c.id===topConcern)?.label}</div>
              <div style={{fontSize:13,color:C.navy,lineHeight:1.75}}>{concernCfg.stageNote(stage)}</div>
            </div>
            {/* なぜ必要か */}
            <div style={{padding:"10px 14px",background:C.sand,borderRadius:10,marginBottom:14}}>
              <div style={{fontSize:10,fontWeight:700,color:C.stone,letterSpacing:".1em",marginBottom:4}}>💡 なぜ今大切なの？</div>
              <div style={{fontSize:12,color:C.stone,lineHeight:1.7}}>{concernCfg.why}</div>
            </div>
            {/* 今育てたい能力 */}
            <div style={{marginBottom:14}}>
              <div style={{fontSize:11,fontWeight:700,color:C.stone,letterSpacing:".08em",marginBottom:8}}>🌱 今育てたい能力</div>
              <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
                {concernCfg.abilities.map((a,i)=>(
                  <div key={i} style={{background:C.violetLt,border:`1.5px solid ${C.violet}44`,borderRadius:20,padding:"5px 14px",fontSize:12,fontWeight:700,color:C.violet}}>{a}</div>
                ))}
              </div>
            </div>
            {/* 優先度スター付き今月やること */}
            <div style={{marginBottom:14}}>
              <div style={{fontSize:11,fontWeight:700,color:C.stone,letterSpacing:".08em",marginBottom:10}}>🎯 今月取り組むこと（優先順）</div>
              {concernCfg.actions.map((a,i)=>(
                <div key={i} style={{display:"flex",alignItems:"flex-start",gap:12,padding:"11px 14px",
                  background:[C.tealLt,C.amberLt,C.sand][i]||C.sand,borderRadius:11,marginBottom:8,
                  border:`1px solid ${[C.teal+"44",C.amber+"44",C.lineCol][i]||C.lineCol}`}}>
                  <div style={{width:28,height:28,borderRadius:"50%",background:[C.teal,C.amber,C.stone][i],color:C.white,fontSize:12,fontWeight:900,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>{i+1}</div>
                  <div style={{flex:1}}>
                    <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:3}}>
                      <span style={{fontSize:18}}>{a.icon}</span>
                      <div style={{display:"flex",gap:2}}>{Array.from({length:5},(_,k)=><span key={k} style={{fontSize:11,color:k<(concernCfg.priority[i]||3)?[C.teal,C.amber,C.stone][i]||C.stone:C.lineCol}}>★</span>)}</div>
                    </div>
                    <span style={{fontSize:13,fontWeight:600,color:C.navy,lineHeight:1.5}}>{a.text}</span>
                    {concernCfg.whyActions?.[i]&&<div style={{fontSize:11,color:C.stone,lineHeight:1.6,marginTop:3}}>💡 {concernCfg.whyActions[i]}</div>}
                  </div>
                </div>
              ))}
            </div>
            {/* 期待できる変化・スポーツメリット */}
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:concernCfg.note?10:0}}>
              <div style={{padding:"10px 12px",background:C.greenLt,borderRadius:10,border:`1px solid ${C.green}22`}}>
                <div style={{fontSize:10,fontWeight:700,color:C.green,marginBottom:4}}>✨ 期待できる変化</div>
                <div style={{fontSize:12,color:C.navy,lineHeight:1.55}}>{concernCfg.benefit}</div>
              </div>
              <div style={{padding:"10px 12px",background:C.blueLt,borderRadius:10,border:`1px solid ${C.blue}22`}}>
                <div style={{fontSize:10,fontWeight:700,color:C.blue,marginBottom:4}}>⚡ スポーツへのメリット</div>
                <div style={{fontSize:12,color:C.navy,lineHeight:1.55}}>{concernCfg.sport}</div>
              </div>
            </div>
            {concernCfg.note&&<div style={{fontSize:11,color:C.stone,marginTop:10,lineHeight:1.6,padding:"8px 12px",background:C.cream,borderRadius:8}}>{concernCfg.note}</div>}
            {/* Dynamic FAQ */}
            {concernCfg.faq&&concernCfg.faq.length>0&&(
              <div style={{marginTop:14}}>
                <div style={{fontSize:11,fontWeight:700,color:C.stone,letterSpacing:".1em",marginBottom:10}}>❓ よくあるご質問（このお悩みに関連）</div>
                {concernCfg.faq.map((item,qi)=>(
                  <div key={qi} style={{marginBottom:10,padding:"10px 14px",background:C.cream,borderRadius:10,border:`1px solid ${C.lineCol}`}}>
                    <div style={{fontSize:12,fontWeight:700,color:C.violet,marginBottom:4}}>Q. {item.q}</div>
                    <div style={{fontSize:12,color:C.stone,lineHeight:1.6}}>A. {item.a}</div>
                  </div>
                ))}
              </div>
            )}
          </Card>
        )}

        {/* ③ 成長ステージ + 見通し — 今どんな成長段階？ */}
        <Card>
          <div style={{fontSize:11,fontWeight:700,color:C.stone,letterSpacing:".12em",marginBottom:4}}>② 今どんな成長段階？</div>
          <GrowthTimeline stage={stage}/>
          <div style={{marginTop:12,padding:"12px 14px",background:stageInfo.color+"14",borderRadius:10,fontSize:13,color:C.navy,lineHeight:1.75,borderLeft:`3px solid ${stageInfo.color}`}}>
            {stageInfo.stageMsg}
          </div>
          {/* growth outlook */}
          <div style={{marginTop:12,padding:"12px 14px",background:C.sand,borderRadius:10,fontSize:12,color:C.stone,lineHeight:1.7}}>
            🌱 <strong>成長の見通し</strong><br/>
            {stageInfo.outlook}
          </div>
          {topConcern==="height"&&(
            <div style={{marginTop:8,padding:"8px 12px",background:C.cream,borderRadius:8,fontSize:11,color:C.stone,lineHeight:1.6}}>
              ※ 本サービスは最終身長を予測・保証するものではありません。お子様が本来もつ成長の力を十分に発揮できるよう、生活習慣・栄養・睡眠・身体機能を整えることを大切にしています。
            </div>
          )}
          {/* stage-based focus areas */}
          {stageInfo.focus.length>0&&(
            <div style={{marginTop:12}}>
              <div style={{fontSize:11,fontWeight:700,color:C.stone,marginBottom:8}}>この時期に大切にしたいこと</div>
              <div style={{display:"flex",flexWrap:"wrap",gap:8}}>
                {stageInfo.focus.map((f,i)=>(
                  <div key={i} style={{background:stageInfo.color+"18",border:`1px solid ${stageInfo.color}44`,borderRadius:20,padding:"4px 12px",fontSize:12,fontWeight:600,color:stageInfo.color}}>{f}</div>
                ))}
              </div>
            </div>
          )}
        </Card>

        {/* 成長適応度スコア */}
        <Card>
          <div style={{fontSize:11,fontWeight:800,color:C.stone,letterSpacing:".12em",marginBottom:12}}>📊 成長適応度（Growth Adaptation Score）</div>
          <div style={{display:"flex",alignItems:"center",gap:16,marginBottom:14}}>
            <ScoreRing score={gas} size={80}/>
            <div style={{flex:1}}>
              <div style={{fontSize:13,color:C.navy,lineHeight:1.7}}>
                {gas>=75?"✅ 身体機能と生活習慣がしっかり整っています。この調子で続けていきましょう！":
                 gas>=55?"身体機能・生活習慣はおおむね順調です。いくつかの取り組みでさらに伸びしろが広がります。":
                        "今は伸びしろがとても大きい時期です。身体づくりを意識することで、これからの成長をしっかり支えられます。"}
              </div>
            </div>
          </div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
            {[{l:"身体機能",v:scores.bodyNorm||0,max:70,c:C.teal},{l:"生活習慣",v:scores.habitScore||0,max:30,c:C.amber}].map(({l,v,max,c},i)=>(
              <div key={i} style={{background:C.sand,borderRadius:10,padding:"10px 14px"}}>
                <div style={{fontSize:11,color:C.stone,marginBottom:4}}>{l}</div>
                <div style={{fontSize:15,fontWeight:800,color:c}}>{v}<span style={{fontSize:10,fontWeight:400}}>%</span></div>
                <div style={{height:4,background:C.lineCol,borderRadius:2,overflow:"hidden",marginTop:4}}>
                  <div style={{width:`${(v/max)*100}%`,height:"100%",background:c,borderRadius:2}}/>
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* ④ 現在の症状 */}
        <div style={{background:hasPain?C.amberLt:C.tealLt,border:`1.5px solid ${hasPain?C.amber:C.teal}`,borderRadius:12,padding:"14px 18px",marginBottom:12,display:"flex",gap:12,alignItems:"flex-start"}}>
          <span style={{fontSize:22,flexShrink:0}}>{hasPain?"🌿":"🟢"}</span>
          <div>
            <div style={{fontSize:12,fontWeight:800,color:hasPain?C.amber:C.teal,marginBottom:3}}>現在の身体の状態</div>
            {hasPain?(
              <>
                <div style={{fontSize:14,fontWeight:700,color:C.navy}}>{(symptom.symptom_parts||[]).filter(p=>p!=="なし").join(" ・ ")} に違和感があります</div>
                <div style={{fontSize:12,color:C.stone,marginTop:2}}>{symptom.symptom_freq} ／ {symptom.symptom_impact}</div>
                <div style={{fontSize:12,color:C.stone,marginTop:4}}>担当スタッフに遠慮なくお伝えください。早めのサポートが安心につながります。</div>
              </>
            ):<div style={{fontSize:14,fontWeight:700,color:C.navy}}>特記する違和感はありません</div>}
          </div>
        </div>

        {/* ⑤ 今育てたい能力 — 5-step cards */}
        {abilities.length>0&&(
          <Card>
            <div style={{fontSize:11,fontWeight:800,color:C.stone,letterSpacing:".12em",marginBottom:14}}>🌱 今育てたい能力</div>
            {abilities.map((ab,i)=>(
              <div key={i} style={{marginBottom:16,border:`1px solid ${C.lineCol}`,borderRadius:14,overflow:"hidden"}}>
                {/* 能力名ヘッダー */}
                <div style={{background:`linear-gradient(135deg,${C.teal},${C.tealDim})`,padding:"10px 16px",display:"flex",alignItems:"center",gap:10}}>
                  <span style={{fontSize:20}}>{ab.icon}</span>
                  <span style={{fontSize:14,fontWeight:800,color:C.white,fontFamily:FF.serif}}>{ab.name}</span>
                </div>
                <div style={{padding:"14px 16px",background:C.white}}>
                  {/* 現状 */}
                  <div style={{marginBottom:10}}>
                    <div style={{fontSize:10,fontWeight:700,color:C.stone,letterSpacing:".1em",marginBottom:4}}>📍 現在の状態</div>
                    <div style={{fontSize:13,color:C.navy,lineHeight:1.6}}>{ab.status}</div>
                  </div>
                  {/* なぜ */}
                  <div style={{marginBottom:10,padding:"10px 12px",background:C.sand,borderRadius:8}}>
                    <div style={{fontSize:10,fontWeight:700,color:C.stone,letterSpacing:".1em",marginBottom:4}}>💡 なぜ今取り組むと良いの？</div>
                    <div style={{fontSize:12,color:C.stone,lineHeight:1.6}}>{ab.why}</div>
                  </div>
                  {/* このままだと */}
                  <div style={{marginBottom:10}}>
                    <div style={{fontSize:10,fontWeight:700,color:C.stone,letterSpacing:".1em",marginBottom:4}}>🔍 今の状態が続くと</div>
                    <div style={{fontSize:12,color:C.stone,lineHeight:1.6}}>{ab.ifNoChange}</div>
                  </div>
                  {/* 今やること */}
                  <div style={{display:"flex",alignItems:"center",gap:10,padding:"10px 14px",background:C.tealLt,borderRadius:10,marginBottom:10,border:`1px solid ${C.teal}33`}}>
                    <span style={{fontSize:20}}>{ab.action.icon}</span>
                    <div>
                      <div style={{fontSize:10,fontWeight:700,color:C.teal,marginBottom:2}}>🎯 今月やること</div>
                      <div style={{fontSize:13,fontWeight:700,color:C.teal}}>{ab.action.text}</div>
                    </div>
                  </div>
                  {/* 期待できる変化・競技メリット */}
                  <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
                    <div style={{padding:"9px 12px",background:C.greenLt,borderRadius:8,border:`1px solid ${C.green}22`}}>
                      <div style={{fontSize:10,fontWeight:700,color:C.green,marginBottom:3}}>✨ 期待できる変化</div>
                      <div style={{fontSize:12,color:C.navy,lineHeight:1.5}}>{ab.benefit}</div>
                    </div>
                    <div style={{padding:"9px 12px",background:C.blueLt,borderRadius:8,border:`1px solid ${C.blue}22`}}>
                      <div style={{fontSize:10,fontWeight:700,color:C.blue,marginBottom:3}}>⚡ スポーツへのメリット</div>
                      <div style={{fontSize:12,color:C.navy,lineHeight:1.5}}>{ab.sport}</div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </Card>
        )}

        {/* ③ 今月取り組むこと — 何を優先？ */}
        <Card>
          <div style={{fontSize:11,fontWeight:800,color:C.stone,letterSpacing:".12em",marginBottom:14}}>📋 今月取り組んでほしいこと（3つだけ）</div>
          {todos.length>0?todos.map((t,i)=>(
            <div key={i} style={{marginBottom:10,borderRadius:12,overflow:"hidden",border:`1px solid ${[C.teal+"44",C.amber+"44",C.lineCol][i]||C.lineCol}`}}>
              <div style={{display:"flex",alignItems:"flex-start",gap:14,padding:"13px 16px",background:[C.tealLt,C.amberLt,C.sand][i]||C.sand}}>
                <div style={{width:30,height:30,borderRadius:"50%",background:[C.teal,C.amber,C.stone][i]||C.stone,color:C.white,fontSize:13,fontWeight:900,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0,fontFamily:FF.serif}}>{i+1}</div>
                <span style={{fontSize:20}}>{t.icon}</span>
                <span style={{fontSize:14,fontWeight:600,color:C.navy,flex:1,lineHeight:1.55}}>{t.text}</span>
              </div>
              {t.why&&(
                <div style={{padding:"10px 16px 10px 60px",background:C.white,fontSize:12,color:C.stone,lineHeight:1.7,borderTop:`1px solid ${C.lineCol}`}}>
                  <span style={{fontWeight:700,color:[C.teal,C.amber,C.stone][i]||C.stone}}>💡 なぜこれをやるの？　</span>{t.why}
                </div>
              )}
            </div>
          )):<div style={{color:C.stone,textAlign:"center",padding:"16px 0",fontSize:13}}>評価データが入力されると表示されます</div>}
        </Card>

        {/* 続けると期待できる変化 */}
        {expectedChanges.length>0&&(
          <Card style={{background:`linear-gradient(135deg,${C.green}08,${C.teal}08)`,border:`1px solid ${C.green}33`}}>
            <div style={{fontSize:11,fontWeight:800,color:C.green,letterSpacing:".12em",marginBottom:12}}>🌟 続けると期待できる変化</div>
            <div style={{display:"flex",flexWrap:"wrap",gap:8}}>
              {expectedChanges.map((c,i)=>(
                <div key={i} style={{display:"flex",alignItems:"center",gap:6,background:C.white,border:`1px solid ${C.green}33`,borderRadius:20,padding:"6px 14px"}}>
                  <span style={{color:C.green,fontWeight:900,fontSize:13}}>✓</span>
                  <span style={{fontSize:12,fontWeight:600,color:C.navy}}>{c}</span>
                </div>
              ))}
            </div>
          </Card>
        )}

        {/* 強み — 現状維持 + さらに強化 */}
        {strengths.length>0&&(
          <Card accent={C.green}>
            <div style={{fontSize:11,fontWeight:800,color:C.green,letterSpacing:".12em",marginBottom:12}}>🌟 確認できている強み（さらに伸ばせる可能性）</div>
            {strengths.map((s,i)=>(
              <div key={i} style={{marginBottom:10,padding:"12px 14px",background:C.greenLt,borderRadius:12,border:`1px solid ${C.green}33`}}>
                <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:6}}>
                  <span style={{fontSize:20}}>{s.icon}</span>
                  <div style={{flex:1}}>
                    <div style={{fontSize:13,fontWeight:700,color:C.green}}>{s.label}</div>
                    <div style={{fontSize:11,color:C.stone,marginTop:2}}>{s.detail}</div>
                  </div>
                  <div style={{background:C.green,color:C.white,borderRadius:8,padding:"2px 10px",fontSize:10,fontWeight:700,flexShrink:0}}>現状維持</div>
                </div>
                <div style={{fontSize:12,color:C.teal,lineHeight:1.5,paddingLeft:30}}>
                  {[
                    "継続することで、さらに土台が安定していきます",
                    "この強みを活かした動きをスポーツで意識してみましょう",
                    "今の習慣が成長を着実に支えています",
                  ][i]||"この強みを維持しながら、さらに伸ばしていきましょう"}
                </div>
              </div>
            ))}
          </Card>
        )}

        {/* Doctor message */}
        {(doctor.eco_summary||doctor.doctor_note||doctor.participation)&&(
          <Card accent={C.blue}>
            <div style={{fontSize:11,fontWeight:800,color:C.blue,letterSpacing:".1em",marginBottom:10}}>🩺 医師からのメッセージ</div>
            {doctor.eco_summary&&<div style={{fontSize:14,fontWeight:600,color:C.navy,marginBottom:6}}>{doctor.eco_summary}</div>}
            {doctor.doctor_note&&<div style={{fontSize:13,color:C.stone,lineHeight:1.7,marginBottom:8}}>{doctor.doctor_note}</div>}
            {doctor.participation&&(
              <div style={{display:"flex",alignItems:"center",gap:10,padding:"10px 14px",background:partColor+"12",borderRadius:8,border:`1px solid ${partColor}33`}}>
                <span style={{fontSize:20,fontWeight:900,color:partColor}}>{partMark}</span>
                <div><div style={{fontSize:10,color:C.stone}}>活動参加の目安</div><div style={{fontSize:13,fontWeight:700,color:partColor}}>{doctor.participation}</div></div>
              </div>
            )}
          </Card>
        )}


        {/* 成長ロードマップ */}
        <Card style={{background:`linear-gradient(135deg,${C.navy}06,${C.teal}08)`,border:`1px solid ${C.teal}33`}}>
          <div style={{fontSize:11,fontWeight:800,color:C.teal,letterSpacing:".12em",marginBottom:14}}>🗺️ これからの成長ロードマップ</div>
          <div style={{display:"flex",flexDirection:"column",gap:0}}>
            {[
              {
                period:"現在",
                tag:STAGES[stage]?.label||"—",
                color:stageInfo.color,
                items:[...(stageInfo.focus||[]).slice(0,3),"身体機能の土台づくり"],
              },
              {
                period:"今後3ヶ月",
                tag:"取り組み期",
                color:C.amber,
                items:[
                  ...todos.slice(0,2).map(t=>(t.text||'').split('（')[0].trim()),
                  "生活習慣の定着",
                ],
              },
              {
                period:"6ヶ月後",
                tag:"変化の時期",
                color:C.teal,
                items:["身体の動かし方の改善","活動中の疲れにくさ向上","成長への適応力向上"],
              },
              {
                period:"1年後",
                tag:"成果の時期",
                color:C.green,
                items:["より安心して活動できる身体","パフォーマンスの向上","長期的な成長サポート"],
              },
            ].map((row,i)=>(
              <div key={i} style={{display:"flex",gap:0}}>
                {/* connector line */}
                <div style={{width:32,display:"flex",flexDirection:"column",alignItems:"center",flexShrink:0}}>
                  <div style={{width:24,height:24,borderRadius:"50%",background:row.color,display:"flex",alignItems:"center",justifyContent:"center",fontSize:11,fontWeight:800,color:C.white,flexShrink:0,zIndex:1}}>{i+1}</div>
                  {i<3&&<div style={{width:2,flex:1,background:`${C.lineCol}`,minHeight:16}}/>}
                </div>
                <div style={{flex:1,paddingLeft:10,paddingBottom:i<3?16:0}}>
                  <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:6}}>
                    <span style={{fontSize:12,fontWeight:800,color:C.navy}}>{row.period}</span>
                    <span style={{background:row.color+"22",border:`1px solid ${row.color}44`,borderRadius:20,padding:"1px 10px",fontSize:10,fontWeight:700,color:row.color}}>{row.tag}</span>
                  </div>
                  <div style={{display:"flex",flexWrap:"wrap",gap:6}}>
                    {row.items.map((it,j)=>(
                      <span key={j} style={{background:C.white,border:`1px solid ${C.lineCol}`,borderRadius:8,padding:"3px 10px",fontSize:11,color:C.stone}}>{it}</span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* 保護者へのメッセージ + よくある相談 */}
        <Card style={{background:`linear-gradient(135deg,${C.navy},${C.navyMid})`,border:"none"}}>
          <div style={{fontSize:12,fontWeight:800,color:"rgba(255,255,255,.5)",letterSpacing:".1em",marginBottom:10}}>保護者の皆さまへ</div>
          <div style={{fontSize:13,color:"rgba(255,255,255,.8)",lineHeight:1.8,marginBottom:16}}>
            今回の評価は、お子様の成長を見守るための一つの目安です。<br/>
            大切なのは点数ではなく、日々の変化です。<br/>
            気になることがありましたら、いつでもお気軽にご相談ください。
          </div>
          {/* Dynamic FAQ: concern-specific or default */}
          <div style={{fontSize:11,fontWeight:700,color:"rgba(255,255,255,.4)",letterSpacing:".1em",marginBottom:10}}>よくあるご相談</div>
          <div style={{display:"flex",flexDirection:"column",gap:8}}>
            {(concernCfg?.faq||[
              {q:"身長はどのくらい伸びる？",a:"成長には個人差があります。睡眠・栄養・身体機能を整えることが、お子様本来の成長力を引き出す後押しになります。"},
              {q:"練習量は適切？",a:"成長期は週10%以内の増加が目安です。急激な増加は身体への負担が大きくなりやすい時期です。"},
              {q:"成長期の痛みはどう見分ける？",a:"繰り返す痛みや活動に影響する場合はスタッフにご相談ください。成長期に起こりやすい痛みは複数あります。"},
              {q:"柔軟性は必要？",a:"特に急成長期は骨の成長に筋肉が追いつきにくいため、柔軟性の維持が大切です。"},
              {q:"何を最初に取り組めばいい？",a:"今回のレポートの「今月取り組むこと」TOP3から始めてみてください。小さな習慣の積み重ねが最も効果的です。"},
            ]).map((item,i)=>(
              <div key={i} style={{background:"rgba(255,255,255,.07)",borderRadius:10,padding:"10px 14px"}}>
                <div style={{fontSize:12,fontWeight:700,color:`${C.teal}`,marginBottom:4}}>Q. {item.q}</div>
                <div style={{fontSize:12,color:"rgba(255,255,255,.65)",lineHeight:1.6}}>{item.a}</div>
              </div>
            ))}
          </div>
        </Card>

        {/* ⑤ 次回評価 */}
        <div style={{background:`linear-gradient(135deg,${C.teal},${C.tealDim})`,borderRadius:14,padding:"16px 22px",display:"flex",alignItems:"center",gap:16,color:C.white}}>
          <span style={{fontSize:32}}>📅</span>
          <div>
            <div style={{fontSize:11,opacity:.7,marginBottom:2}}>⑤ 次回評価の目安</div>
            <div style={{fontSize:18,fontWeight:800,fontFamily:FF.serif}}>3〜4ヶ月後</div>
            <div style={{fontSize:12,opacity:.65,marginTop:2}}>成長・身体機能・生活習慣の変化を確認します</div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════════
   REPORT: ATHLETE
══════════════════════════════════════════════ */
function AthleteReport({all}){
  const {basic={},symptom={},habit={},doctor={},scores={},body={}} = all;
  const title = genTitle(body, habit);
  const strengths = detectStrengths(body, habit, symptom);
  const hasPain = (symptom.symptom_parts||[]).some(p=>p!=="なし");
  const stage = doctor.stage||"peak";
  const stageInfo = STAGES[stage]||STAGES.peak;
  const gas = scores.gas||0;
  const missions = genTodos(symptom, habit, body, stage, basic.concerns||[]);
  const name = basic.name||"あなた";

  return(
    <div style={{fontFamily:FF.sans,maxWidth:700,margin:"0 auto"}}>
      <div style={{background:`linear-gradient(135deg,${C.dark} 0%,#1A3A50 100%)`,borderRadius:"18px 18px 0 0",padding:"24px 26px 20px",position:"relative",overflow:"hidden"}}>
        <div style={{position:"absolute",right:-50,top:-50,width:180,height:180,borderRadius:"50%",background:`${C.teal}18`}}/>
        <div style={{fontSize:9,letterSpacing:".2em",color:"rgba(255,255,255,.35)",marginBottom:6}}>joynity Growth Check</div>
        <div style={{fontSize:20,fontWeight:900,color:C.white,fontFamily:FF.serif,marginBottom:4}}>{name}へ</div>
        <div style={{fontSize:12,color:"rgba(255,255,255,.55)"}}>今の体の状態と、今月のミッションを確認しよう</div>
      </div>
      <div style={{background:title.color+"18",borderBottom:`1px solid ${C.lineCol}`,padding:"16px 22px",display:"flex",alignItems:"center",gap:14}}>
        <div style={{width:58,height:58,borderRadius:"50%",background:title.color,display:"flex",alignItems:"center",justifyContent:"center",fontSize:26,boxShadow:`0 4px 14px ${title.color}44`,flexShrink:0}}>{title.icon}</div>
        <div><div style={{fontSize:10,fontWeight:700,color:title.color,letterSpacing:".1em",marginBottom:2}}>今日の称号</div><div style={{fontSize:22,fontWeight:900,color:title.color,fontFamily:FF.serif}}>{title.title}</div></div>
        <div style={{marginLeft:"auto"}}><ScoreRing score={gas} size={66}/><div style={{fontSize:9,color:C.stone,textAlign:"center",marginTop:2}}>成長適応度</div></div>
      </div>

      <div style={{background:C.sand,padding:"14px 14px 22px",borderRadius:"0 0 18px 18px"}}>
        {/* Stage message */}
        <Card>
          <div style={{fontSize:11,fontWeight:700,color:C.stone,marginBottom:8}}>🚀 今の成長ステージ</div>
          <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:8}}>
            <div style={{background:stageInfo.color+"22",border:`1.5px solid ${stageInfo.color}`,borderRadius:20,padding:"4px 14px",fontSize:13,fontWeight:800,color:stageInfo.color}}>{stageInfo.icon} {stageInfo.label}</div>
            <span style={{fontSize:12,color:C.stone}}>{stageInfo.jp}</span>
          </div>
          <div style={{fontSize:13,color:C.navy,lineHeight:1.7}}>{stageInfo.stageMsg}</div>
        </Card>

        {/* Monthly missions */}
        <Card>
          <div style={{fontSize:13,fontWeight:800,color:C.navy,marginBottom:14}}>🎯 今月のミッション</div>
          {missions.map((m,i)=>(
            <div key={i} style={{display:"flex",alignItems:"center",gap:12,padding:"12px 14px",background:[C.tealLt,C.amberLt,C.violetLt][i]||C.sand,borderRadius:10,border:`1px solid ${[C.teal+"44",C.amber+"44",C.violet+"44"][i]||C.lineCol}`,marginBottom:8}}>
              <div style={{width:28,height:28,borderRadius:"50%",background:[C.teal,C.amber,C.violet][i]||C.stone,color:C.white,fontSize:13,fontWeight:900,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0,fontFamily:FF.serif}}>{i+1}</div>
              <span style={{fontSize:18}}>{m.icon}</span>
              <span style={{fontSize:13,fontWeight:600,color:C.navy,flex:1}}>{m.text}</span>
            </div>
          ))}
        </Card>

        {strengths.length>0&&(
          <Card>
            <div style={{fontSize:13,fontWeight:800,color:C.navy,marginBottom:12}}>✨ あなたの強み</div>
            <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
              {strengths.map((s,i)=>(
                <div key={i} style={{flex:"1 0 140px",padding:"12px 14px",background:C.greenLt,borderRadius:12,border:`1.5px solid ${C.green}33`,textAlign:"center"}}>
                  <div style={{fontSize:22,marginBottom:4}}>{s.icon}</div>
                  <div style={{fontSize:12,fontWeight:700,color:C.green}}>{s.label}</div>
                  <div style={{fontSize:10,color:C.stone,marginTop:2}}>{s.detail}</div>
                </div>
              ))}
            </div>
          </Card>
        )}

        {hasPain&&(
          <div style={{background:C.amberLt,border:`2px solid ${C.amber}`,borderRadius:12,padding:"14px 18px",display:"flex",gap:12,alignItems:"center",marginBottom:12}}>
            <span style={{fontSize:24}}>🌿</span>
            <div>
              <div style={{fontSize:13,fontWeight:800,color:C.amber,marginBottom:2}}>身体のサインを大切に</div>
              <div style={{fontSize:13,color:C.navy}}>{(symptom.symptom_parts||[]).filter(p=>p!=="なし").join("・")}に違和感があります。無理せず、担当スタッフに伝えてください。</div>
            </div>
          </div>
        )}

        <div style={{background:C.navy,borderRadius:14,padding:"16px 22px",color:C.white,textAlign:"center"}}>
          <div style={{fontSize:15,fontWeight:900,fontFamily:FF.serif,marginBottom:5}}>
            {gas>=75?"この調子で続けよう！🎉":gas>=55?"もう少しだけ習慣を整えよう💪":"今が大切な時期。一緒に成長を支えていこう🌱"}
          </div>
          <div style={{fontSize:11,opacity:.6,lineHeight:1.6}}>毎日の小さな積み重ねが、将来の健康とパフォーマンスを育てます。</div>
        </div>
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════════
   REPORT: COACH
══════════════════════════════════════════════ */
function CoachReport({all}){
  const {basic={},symptom={},habit={},doctor={},scores={},body={}} = all;
  const stage = doctor.stage||"peak";
  const stageL = {pre:"Pre PHV",peak:"Peak PHV",post:"Post PHV",hold:"判定中"}[stage]||"—";
  const hasPain = (symptom.symptom_parts||[]).some(p=>p!=="なし");
  const canParticipate = doctor.participation!=="医師へ相談推奨" && symptom.symptom_impact!=="休む必要がある";
  const partColor = {通常参加可能:C.teal,"状況に応じて調整":C.amber,"医師へ相談推奨":C.coral}[doctor.participation]||C.stone;
  const gas = scores.gas||0;

  const points=[];
  if(doctor.participation==="医師へ相談推奨") points.push({icon:"🩺",text:"活動の進め方を医師にご確認ください",level:"stop"});
  if(doctor.participation==="状況に応じて調整") points.push({icon:"🌿",text:"一部の動作は調整しながら進めるのがおすすめです",level:"caution"});
  if(symptom.symptom_impact==="休む必要がある") points.push({icon:"🌿",text:`${(symptom.symptom_parts||[]).filter(p=>p!=="なし").join("・")}を今は休ませてあげたい時期です`,level:"stop"});
  if(stage==="peak") points.push({icon:"📏",text:"急成長期です。活動量はゆるやかに増やしていきましょう",level:"caution"});
  if(body.flex?.hbdPos||body.flex?.slrLow) points.push({icon:"🦵",text:"太もも・もも裏の柔軟性を高めるサポートが有効です",level:"info"});
  if(body.trunk?.thorBad) points.push({icon:"🔄",text:"胸椎の動きを育てる働きかけがおすすめです",level:"info"});
  if(body.coord?.slsBad) points.push({icon:"⚖️",text:"片脚動作の安定性を育てるサポートを取り入れましょう",level:"info"});
  if(["なし","月数回"].includes(habit.snack)) points.push({icon:"🍙",text:"活動後の補食習慣を育てる声かけが効果的です",level:"info"});
  if(["6時間未満","6〜7時間","7〜8時間"].includes(habit.sleep)) points.push({icon:"🌙",text:"睡眠を整えるとよりよいコンディションが期待できます",level:"info"});

  const lCfg={stop:{color:C.coral,bg:C.coralLt,label:"要確認"},caution:{color:C.amber,bg:C.amberLt,label:"サポート"},info:{color:C.blue,bg:C.blueLt,label:"おすすめ"}};

  return(
    <div style={{fontFamily:FF.sans,maxWidth:700,margin:"0 auto"}}>
      <div style={{background:C.navyMid,borderRadius:"14px 14px 0 0",padding:"14px 22px",display:"flex",alignItems:"center",gap:10}}>
        <div style={{background:C.amber,color:C.white,borderRadius:6,padding:"2px 10px",fontSize:11,fontWeight:800}}>COACH</div>
        <div style={{color:C.white,fontSize:15,fontWeight:800,fontFamily:FF.serif}}>指導サポートサマリー（30秒で確認）</div>
      </div>
      {/* Quick strip */}
      <div style={{background:C.white,padding:"14px 18px",display:"flex",gap:0,flexWrap:"wrap",borderBottom:`1px solid ${C.lineCol}`}}>
        {[{l:"氏名",v:basic.name||"—"},{l:"活動",v:basic.sport||"—"},{l:"成長ステージ",v:stageL},{l:"適応度スコア",v:`${gas}%`},{l:"活動参加",v:doctor.participation||"—",c:partColor}].map(({l,v,c},i)=>(
          <div key={i} style={{flex:1,minWidth:70,textAlign:"center",padding:"0 6px",borderRight:i<4?`1px solid ${C.lineCol}`:"none"}}>
            <div style={{fontSize:9,color:C.stone,marginBottom:2}}>{l}</div>
            <div style={{fontSize:12,fontWeight:700,color:c||C.navy}}>{v}</div>
          </div>
        ))}
      </div>

      <div style={{background:C.sand,padding:"14px 14px 18px",borderRadius:"0 0 14px 14px"}}>
        <Card>
          <ST color={C.amber}>本日のサポートポイント</ST>
          {points.length>0?points.map((p,i)=>{
            const cfg=lCfg[p.level];
            return <div key={i} style={{display:"flex",alignItems:"center",gap:12,padding:"11px 14px",background:cfg.bg,borderRadius:10,border:`1.5px solid ${cfg.color}44`,marginBottom:8}}>
              <span style={{fontSize:20,flexShrink:0}}>{p.icon}</span>
              <span style={{fontSize:13,fontWeight:600,color:C.navy,flex:1,lineHeight:1.5}}>{p.text}</span>
              <div style={{background:cfg.color,color:C.white,borderRadius:6,padding:"2px 7px",fontSize:10,fontWeight:800,flexShrink:0}}>{cfg.label}</div>
            </div>;
          }):<div style={{textAlign:"center",color:C.stone,padding:"14px 0",fontSize:13}}>特別なサポートポイントはありません。順調です。</div>}
        </Card>

        {/* stage focus */}
        <Card>
          <ST color={C.teal}>成長ステージ別の重点事項</ST>
          <div style={{display:"flex",flexWrap:"wrap",gap:8}}>
            {(STAGES[stage]?.focus||[]).map((f,i)=>(
              <div key={i} style={{background:(STAGES[stage]?.color||C.teal)+"18",border:`1px solid ${STAGES[stage]?.color||C.teal}44`,borderRadius:20,padding:"5px 14px",fontSize:12,fontWeight:600,color:STAGES[stage]?.color||C.teal}}>{f}</div>
            ))}
          </div>
        </Card>

        <Card>
          <ST color={C.stone}>生活習慣の状況</ST>
          <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:8}}>
            {[{l:"睡眠",v:habit.sleep,ok:["8〜9時間","9時間以上"].includes(habit.sleep)},{l:"補食",v:habit.snack,ok:["週3〜4回","週5回以上"].includes(habit.snack)},{l:"水分",v:habit.hydration,ok:["活動中に定期的に飲む","活動量に応じて意識して増やしている"].includes(habit.hydration)},{l:"セルフケア",v:habit.selfcare,ok:["週3〜4回","週5回以上"].includes(habit.selfcare)},{l:"自主トレ",v:habit.self_training,ok:["週1〜2回","週3〜4回","週5回以上"].includes(habit.self_training)}].map(({l,v,ok},i)=>(
              <div key={i} style={{background:ok?C.tealLt:"rgba(0,0,0,.03)",borderRadius:10,padding:"10px 12px",textAlign:"center",border:`1px solid ${ok?C.teal+"33":C.lineCol}`}}>
                <div style={{fontSize:10,color:C.stone,marginBottom:3}}>{l}</div>
                <div style={{fontSize:11,fontWeight:700,color:ok?C.teal:C.navy,lineHeight:1.4}}>{v||"未入力"}</div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════════
   REPORT: DETAIL (Radar + table)
══════════════════════════════════════════════ */
function DetailReport({all}){
  const {body={},scores={}} = all;
  const radar=[body.rom?.pct??50,body.flex?.pct??50,body.trunk?.pct??50,body.coord?.pct??50,body.str?.pct??50,body.bal?.pct??50];
  const gas = scores.gas||0;
  const ev = body._ev||{};

  return(
    <div style={{fontFamily:FF.sans,maxWidth:700,margin:"0 auto"}}>
      <Card>
        <ST color={C.teal}>成長適応度（Growth Adaptation Score）</ST>
        <div style={{background:C.tealLt,borderRadius:10,padding:"12px 16px",marginBottom:16,fontSize:13,color:C.navy,lineHeight:1.7}}>
          <strong>総合スコア：{gas}点 / 100点</strong><br/>
          {gas>=75?"成長と身体づくりがバランスよく育っています。":gas>=55?"身体機能・生活習慣はおおむね順調。さらに伸ばせる伸びしろがあります。":"伸びしろの大きい時期です。身体機能と生活習慣を整えることで成長をしっかり支えられます。"}
        </div>
        <div style={{display:"flex",gap:20,flexWrap:"wrap",alignItems:"center"}}>
          <div style={{flex:"0 0 auto"}}><Radar scores={radar} labels={["可動域","柔軟性","体幹","協調","筋力","バランス"]} size={220}/></div>
          <div style={{flex:1,minWidth:180}}>
            {["可動域","柔軟性","体幹","協調","筋力","バランス"].map((lb,i)=>{
              const sc=radar[i];const noData=sc===50&&i>0;
              return(<div key={i} style={{marginBottom:10}}>
                <div style={{display:"flex",justifyContent:"space-between",fontSize:12,marginBottom:3}}>
                  <span style={{color:C.navy,fontWeight:600}}>{lb}</span>
                  <span style={{fontWeight:700,color:sc>=70?C.teal:sc>=45?C.amber:C.coral}}>{sc}%</span>
                </div>
                <div style={{height:5,background:C.lineCol,borderRadius:3,overflow:"hidden"}}>
                  <div style={{width:`${sc}%`,height:"100%",background:sc>=70?C.teal:sc>=45?C.amber:C.coral,borderRadius:3}}/>
                </div>
              </div>);
            })}
            <div style={{marginTop:14,padding:"10px 14px",background:C.tealLt,borderRadius:10,textAlign:"center"}}>
              <div style={{fontSize:10,color:C.stone}}>総合スコア</div>
              <div style={{fontSize:24,fontWeight:900,color:C.teal,fontFamily:FF.serif}}>{scores.bodyNorm||0}<span style={{fontSize:11,fontWeight:400}}>%</span></div>
              <div style={{fontSize:11,fontWeight:700,color:C.teal}}>{(scores.bodyNorm||0)>=60?"A — Excellent":(scores.bodyNorm||0)>=45?"B — Good":(scores.bodyNorm||0)>=30?"C — Fair":"D — Needs Work"}</div>
            </div>
          </div>
        </div>
      </Card>
      <div style={{background:C.blueLt,border:`1px solid ${C.blue}33`,borderRadius:8,padding:"8px 14px",marginBottom:12,fontSize:11,color:C.blue}}>
        💡「非実施」の項目はスコア計算から除外し、実施項目のみで換算しています。
      </div>
      <Card>
        <ST color={C.navy}>測定値詳細</ST>
        <table style={{width:"100%",borderCollapse:"collapse",fontSize:12}}>
          <thead><tr style={{background:C.sand}}>{["評価項目","右(R)","左(L)","成長サポートポイント"].map((h,i)=><th key={i} style={{padding:"7px 10px",textAlign:i===0?"left":"center",fontSize:11,fontWeight:700,color:C.stone,borderBottom:`1px solid ${C.lineCol}`}}>{h}</th>)}</tr></thead>
          <tbody>
            {[{l:"SLR",r:ev.slr_r||"—",l2:ev.slr_l||"—",good:ev.slr_r==="90度"&&ev.slr_l==="90度",pos:"もも裏の柔軟性に伸びしろ",neg:"✓ 良好"},
              {l:"HBD",r:ev.hbd_r_ok===true?"OK":ev.hbd_r_ok===false?"NG":"—",l2:ev.hbd_l_ok===true?"OK":ev.hbd_l_ok===false?"NG":"—",good:ev.hbd_r_ok&&ev.hbd_l_ok,pos:"大腿前面の柔軟性に伸びしろ",neg:"✓ 良好"},
              {l:"片脚屈伸",r:ev.sls_r||"—",l2:ev.sls_l||"—",good:ev.sls_r==="できる"&&ev.sls_l==="できる",pos:"片脚支持能力に伸びしろ",neg:"✓ 良好"},
              {l:"片脚立位",r:ev.slb_r||"—",l2:ev.slb_l||"—",good:ev.slb_r==="30秒完全にできる"&&ev.slb_l==="30秒完全にできる",pos:"バランス能力に伸びしろ",neg:"✓ 良好"},
              {l:"Push-up",r:ev.pushup||"—",l2:"—",good:ev.pushup==="額レベルでできる",pos:"体幹機能に伸びしろ",neg:"✓ 良好"},
              {l:"呼吸",r:ev.breath||"—",l2:"—",good:ev.breath==="呼気6秒できる",pos:"呼吸機能に伸びしろ",neg:"✓ 良好"},
              {l:"垂直跳び",r:ev.vertical_jump||"—",l2:"—",good:ev.vertical_jump==="年齢平均以上",pos:"跳躍力に伸びしろ",neg:"✓ 良好"},
            ].map((row,i)=>(
              <tr key={i} style={{borderBottom:`1px solid ${C.lineCol}`}}>
                <td style={{padding:"9px 10px",fontWeight:600,color:C.navy}}>{row.l}</td>
                <td style={{padding:"9px 10px",textAlign:"center",color:row.r===NA_OPT?C.stone:C.navy,fontSize:row.r===NA_OPT?11:12}}>{row.r}</td>
                <td style={{padding:"9px 10px",textAlign:"center",color:row.l2===NA_OPT?C.stone:C.navy,fontSize:row.l2===NA_OPT?11:12}}>{row.l2}</td>
                <td style={{padding:"9px 10px",textAlign:"center",fontSize:11,fontWeight:600,color:row.r===NA_OPT?C.stone:row.good?C.teal:C.amber}}>
                  {row.r===NA_OPT?"除外":row.good?row.neg:row.pos}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </div>
  );
}

/* ══════════════════════════════════════════════
   REPORT: STAFF
══════════════════════════════════════════════ */
function StaffReport({all}){
  const {basic={},symptom={},habit={},doctor={},scores={},body={},ev={}} = all;
  const [draft,setDraft]=useState(null);
  const draftTxt=draft??genDraft(doctor,body,symptom,habit);
  const stage=doctor.stage||"peak";
  const hasPain=(symptom.symptom_parts||[]).some(p=>p!=="なし");
  const abilities=extractAbilities(body,habit,stage);

  const issues=[];
  if(hasPain){
    const factors=[];
    if(stage==="peak") factors.push("急成長期で骨が先行して伸び、筋・腱が追いつく途中の時期です");
    if(body.flex?.hbdPos) factors.push("HBD陽性：大腿前面の柔軟性に伸びしろ（骨端部への負担を和らげたい）");
    if(body.flex?.slrLow) factors.push("SLRに伸びしろ：もも裏の柔軟性を高めると骨盤・腰がより安定します");
    if(symptom.pain_response==="違和感があっても続けている") factors.push("現在も活動を継続中。早めにケアを取り入れたい状況です");
    if(["6時間未満","6〜7時間"].includes(habit.sleep)) factors.push("睡眠を整えると、組織修復・成長ホルモン分泌がより高まります");
    if(["なし","月数回"].includes(habit.snack)) factors.push("活動後の補食を増やすと、筋合成・エネルギー回復がより進みます");
    const interventions=[];
    if(body.flex?.hbdPos) interventions.push("大腿直筋・TFLリリース（フォームローラー2分 → スタティック30秒×3）");
    if(body.flex?.slrLow) interventions.push("ハムストリングスPNFストレッチ（Contract-Relax法、週4回以上）");
    interventions.push("活動量の週次モニタリング（前週比10%増加ルール）");
    if(body.trunk?.pushupBad) interventions.push("体幹安定化：修正デッドバグ → 呼吸練習 → 通常デッドバグへ段階移行");
    issues.push({label:"サポート①",title:`${(symptom.symptom_parts||[]).filter(p=>p!=="なし").join(" ・ ")} を大切にしたいポイント`,color:C.coral,factors,interventions});
  }

  const funcIssues=[];
  if(body.trunk?.thorBad) funcIssues.push("胸椎の可動性に伸びしろ：肩・腰の動きをより楽にできます");
  if(body.trunk?.pushupBad) funcIssues.push("体幹・肩甲帯の安定性に伸びしろがあります");
  if(body.trunk?.breathBad) funcIssues.push("呼吸（横隔膜・胸郭）の機能を高める余地があります");
  if(funcIssues.length>0) issues.push({label:"サポート②",title:"これから伸ばしたい身体機能",color:C.amber,factors:funcIssues,
    interventions:["胸椎モビリティ改善：四つ這い胸椎回旋（10rep×3set、朝晩）","呼吸練習：腹式呼吸習得 → 鼻呼気6秒の段階練習","次回評価でHBD・SLR・胸椎回旋の変化を数値で確認"]});

  const hIssues=[];
  if(["6時間未満","6〜7時間"].includes(habit.sleep)) hIssues.push(`睡眠${habit.sleep}：整えると成長ホルモン分泌がより高まります（十代の目安：8〜10時間）`);
  if(["なし","月数回"].includes(habit.snack)) hIssues.push("活動後の補食を増やすと、筋合成・エネルギー回復がより進みます");
  if(hIssues.length>0) issues.push({label:"サポート③",title:"成長を支える生活習慣",color:C.violet,factors:hIssues,
    interventions:["保護者に睡眠の重要性を具体的に説明（成長ホルモンは入眠後1〜3時間に集中分泌）","補食の具体例を提案（おにぎり＋牛乳 / バナナ＋ヨーグルト）","セルフケアルーティン表を家族と一緒に作成・掲示を推奨"]});

  const nextCheck=["HBD・SLRの再測定（数値変化の確認）",
    hasPain&&`${(symptom.symptom_parts||[]).filter(p=>p!=="なし").join("・")}の変化（違和感の増減）`,
    stage==="peak"&&"身長・体重の変化（成長速度の算出）",
    "生活習慣3項目の実践状況確認",
    doctor.participation==="医師へ相談推奨"&&"医師への活動参加可否の確認（状況を共有）",
    basic.joynity_plan&&`介入内容：${basic.joynity_plan}の効果確認`,
  ].filter(Boolean);

  return(
    <div style={{fontFamily:FF.sans,maxWidth:700,margin:"0 auto"}}>
      <div style={{background:C.navy,borderRadius:"14px 14px 0 0",padding:"12px 22px",display:"flex",alignItems:"center",gap:10}}>
        <div style={{background:C.coral,color:C.white,borderRadius:6,padding:"2px 10px",fontSize:11,fontWeight:800}}>STAFF</div>
        <div style={{color:C.white,fontSize:15,fontWeight:800,fontFamily:FF.serif}}>介入計画・成長サポートアセスメント</div>
        <div style={{marginLeft:"auto",fontSize:11,color:"rgba(255,255,255,.4)"}}>成長適応度 {scores.gas||0}% ／ 身体 {scores.bodyNorm||0}%</div>
      </div>
      <div style={{background:C.blueLt,borderBottom:`1px solid ${C.lineCol}`,padding:"14px 20px"}}>
        <div style={{fontSize:11,fontWeight:700,color:C.blue,marginBottom:8}}>🩺 医師所見文章（自動下書き）— ご確認・修正の上ご使用ください</div>
        <textarea value={draftTxt} onChange={e=>setDraft(e.target.value)} rows={3}
          style={{width:"100%",padding:"10px 12px",border:`1.5px solid ${C.blue}44`,borderRadius:10,fontSize:13,color:C.navy,background:C.white,fontFamily:FF.sans,outline:"none",boxSizing:"border-box",resize:"vertical",lineHeight:1.7}}/>
        <button onClick={()=>setDraft(null)} style={{marginTop:6,padding:"4px 12px",borderRadius:6,border:`1px solid ${C.blue}`,background:"transparent",color:C.blue,fontSize:11,cursor:"pointer"}}>↺ 自動生成に戻す</button>
      </div>
      <div style={{background:C.sand,padding:"14px 14px 20px",borderRadius:"0 0 14px 14px"}}>
        {doctor.participation==="医師へ相談推奨"&&<div style={{background:C.amberLt,border:`2px solid ${C.amber}`,borderRadius:12,padding:"12px 18px",marginBottom:12}}>
          <div style={{fontSize:13,fontWeight:800,color:C.amber,marginBottom:4}}>🩺 活動参加：医師へ相談推奨</div>
          <div style={{fontSize:13,color:C.navy}}>{doctor.eco_summary||"成長評価に基づく確認推奨。介入内容は医師と協議の上で決定してください。"}</div>
        </div>}

        {issues.length>0?issues.map((iss,i)=>(
          <Card key={i} accent={iss.color}>
            <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:14}}>
              <div style={{background:iss.color,color:C.white,borderRadius:6,padding:"2px 10px",fontSize:11,fontWeight:800}}>{iss.label}</div>
              <div style={{fontSize:14,fontWeight:800,color:C.navy}}>{iss.title}</div>
            </div>
            <div style={{marginBottom:12}}>
              <div style={{fontSize:11,fontWeight:700,color:C.stone,letterSpacing:".08em",marginBottom:8}}>▶ 背景にある成長の変化</div>
              {iss.factors.map((f,j)=><div key={j} style={{display:"flex",gap:8,marginBottom:5,fontSize:13,color:C.navy,lineHeight:1.5}}><span style={{color:iss.color,fontWeight:700,flexShrink:0}}>•</span><span>{f}</span></div>)}
            </div>
            <div style={{background:C.cream,borderRadius:10,padding:"12px 14px",border:`1px solid ${iss.color}22`}}>
              <div style={{fontSize:11,fontWeight:700,color:C.stone,letterSpacing:".08em",marginBottom:8}}>▶ 介入方針</div>
              {iss.interventions.map((it,j)=><div key={j} style={{display:"flex",gap:10,marginBottom:7,fontSize:13,color:C.navy,lineHeight:1.5}}><span style={{fontWeight:800,color:iss.color,flexShrink:0}}>{j+1}.</span><span>{it}</span></div>)}
            </div>
          </Card>
        )):<Card><div style={{textAlign:"center",color:C.stone,padding:"20px 0"}}>評価データを入力すると介入計画が自動生成されます</div></Card>}

        <Card accent={C.teal}>
          <ST color={C.teal}>次回来院時の確認事項</ST>
          {nextCheck.map((item,i)=>(
            <div key={i} style={{display:"flex",gap:10,alignItems:"flex-start",padding:"8px 10px",background:C.sand,borderRadius:8,marginBottom:6}}>
              <div style={{width:18,height:18,border:`2px solid ${C.teal}`,borderRadius:4,flexShrink:0,marginTop:1}}/>
              <span style={{fontSize:13,color:C.navy,lineHeight:1.5}}>{item}</span>
            </div>
          ))}
        </Card>

        {/* ability-based summary — staff 5-step */}
        {abilities.length>0&&(
          <Card>
            <ST color={C.navy}>今育てたい能力サマリー（介入優先度）</ST>
            {abilities.map((ab,i)=>(
              <div key={i} style={{marginBottom:12,padding:"12px 14px",background:C.sand,borderRadius:10,border:`1px solid ${C.lineCol}`}}>
                <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:8}}>
                  <span style={{fontSize:18}}>{ab.icon}</span>
                  <div style={{background:C.teal,color:C.white,borderRadius:20,padding:"2px 10px",fontSize:11,fontWeight:800}}>{ab.name}</div>
                  <div style={{display:"flex",gap:1,marginLeft:"auto"}}>{Array.from({length:5},(_,k)=><span key={k} style={{fontSize:11,color:k<ab.priority?C.teal:C.lineCol}}>★</span>)}</div>
                </div>
                <div style={{fontSize:12,color:C.stone,lineHeight:1.5,marginBottom:6}}>{ab.status}</div>
                <div style={{fontSize:12,color:C.stone,lineHeight:1.5,marginBottom:8,padding:"8px 10px",background:C.white,borderRadius:8}}>{ab.why}</div>
                <div style={{display:"flex",alignItems:"center",gap:8,padding:"8px 12px",background:C.tealLt,borderRadius:8,marginBottom:6}}>
                  <span style={{fontSize:16}}>{ab.action.icon}</span>
                  <span style={{fontSize:12,fontWeight:600,color:C.teal}}>{ab.action.text}</span>
                </div>
                <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:6}}>
                  <div style={{fontSize:11,color:C.green,padding:"5px 10px",background:C.greenLt,borderRadius:6}}>✨ {ab.benefit}</div>
                  <div style={{fontSize:11,color:C.blue,padding:"5px 10px",background:C.blueLt,borderRadius:6}}>⚡ {ab.sport}</div>
                </div>
              </div>
            ))}
          </Card>
        )}
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════════
   MAIN APP
══════════════════════════════════════════════ */
const STEPS=[{id:"basic",label:"基本情報",icon:"👤"},{id:"symptom",label:"症状",icon:"🔴"},{id:"function",label:"身体機能",icon:"🦴"},{id:"habit",label:"生活習慣",icon:"📅"},{id:"doctor",label:"医師評価",icon:"🩺"},{id:"report",label:"レポート",icon:"📄"}];

export default function App(){
  const [step,setStep]=useState(0);
  const [repTab,setRepTab]=useState(0);
  const [csvMsg,setCsvMsg]=useState("");
  const intakeRef=useRef(null);

  const [basic,setBasic]=useState({name:"",eval_date:new Date().toISOString().slice(0,10),trainer:"",sport:"",age:"",grade:"",player_id:"",height:"",weight:"",joynity_plan:"",next_doctor_check:"",concerns:[]});
  const [symptom,setSymptom]=useState({symptom_parts:["なし"],symptom_freq:"なし",symptom_timing:["なし"],symptom_impact:"なし",pain_response:"",parent_concern:"",player_concern:""});
  const [habit,setHabit]=useState({sleep:"",snack:"",selfcare:"",hydration:"",self_training:""});
  const [ev,setEv]=useState({thoracic_ok_str:"",squat_limit:"",slr_r:"",slr_l:"",hbd_r_ok:null,hbd_l_ok:null,pelvis_r:"",pelvis_l:"",pushup:"",breath:"",squat_coord:"",sls_r:"",sls_l:"",vertical_jump:"",strength_r:"",strength_l:"",step_r:"",step_l:"",tandem_r:"",tandem_l:"",slb_r:"",slb_l:"",staff_memo:""});
  const [doctor,setDoctor]=useState({growth_type:"",stage:"peak",eco_summary:"",eco_finding:"",doctor_note:"",movement_note:"",participation:"通常参加可能"});

  const sB=k=>v=>setBasic(p=>({...p,[k]:v}));
  const sS=k=>v=>setSymptom(p=>({...p,[k]:v}));
  const sH=k=>v=>setHabit(p=>({...p,[k]:v}));
  const sE=k=>v=>setEv(p=>({...p,[k]:v}));
  const sD=k=>v=>setDoctor(p=>({...p,[k]:v}));

  const computed=useMemo(()=>{
    const bodyRaw=scoreBody(ev);
    bodyRaw._ev=ev;
    const habitSc=scoreHabit(habit);
    const gas=calcGAS(bodyRaw.norm,habitSc);
    const status=calcStatus(gas,symptom,doctor.participation);
    return{gas,bodyNorm:bodyRaw.norm,habitScore:habitSc,status,body:bodyRaw};
  },[ev,habit,symptom,doctor.participation]);

  const all={basic,symptom,habit,ev,doctor,scores:computed,body:computed.body};

  const loadCSV=e=>{
    const file=e.target.files?.[0];if(!file)return;
    const reader=new FileReader();
    reader.onload=ev2=>{
      try{
        const p=parseIntakeCSV(ev2.target.result);
        [["name",sB],["age",sB],["grade",sB],["sport",sB],["height",sB],["weight",sB],
         ["symptom_freq",sS],["symptom_impact",sS],["pain_response",sS],["parent_concern",sS],["player_concern",sS],
         ["sleep",sH],["snack",sH],["selfcare",sH],["hydration",sH],["self_training",sH],
        ].forEach(([k,fn])=>{if(p[k])fn(k)(p[k]);});
        if(p.symptom_parts) sS("symptom_parts")(p.symptom_parts.split("|"));
        if(p.symptom_timing) sS("symptom_timing")(p.symptom_timing.split("|"));
        setCsvMsg("✓ 事前入力データを読み込みました");setTimeout(()=>setCsvMsg(""),3000);
      }catch{setCsvMsg("❌ 読み込みエラー");}
    };
    reader.readAsText(file,"utf-8");
  };

  const handleExport=()=>{
    const blob=new Blob([exportCSV(all)],{type:"text/csv;charset=utf-8;"});
    const url=URL.createObjectURL(blob);
    const a=document.createElement("a");a.href=url;a.download=`${basic.name||"gc"}_${basic.eval_date||"data"}.csv`;a.click();URL.revokeObjectURL(url);
  };
  const handlePrint=()=>window.print();

  const inp=(k,st,se,ph,type)=><input type={type||"text"} value={st[k]||""} onChange={e=>se(k)(e.target.value)} placeholder={ph} style={{width:"100%",padding:"9px 12px",border:`1.5px solid ${C.lineCol}`,borderRadius:10,fontSize:13,color:C.navy,background:C.cream,fontFamily:FF.sans,outline:"none",boxSizing:"border-box"}}/>;
  const ta=(k,st,se,ph,rows=2)=><textarea value={st[k]||""} onChange={e=>se(k)(e.target.value)} rows={rows} placeholder={ph} style={{width:"100%",padding:"9px 12px",border:`1.5px solid ${C.lineCol}`,borderRadius:10,fontSize:13,color:C.navy,background:C.cream,fontFamily:FF.sans,outline:"none",boxSizing:"border-box",resize:"vertical"}}/>;
  const withNA=opts=>[...opts,NA_OPT];

  return(
    <div style={{minHeight:"100vh",background:C.sand,fontFamily:FF.sans}}>
      <style>{PRINT_CSS}</style>

      {/* Top bar */}
      <div className="no-print" style={{background:C.white,borderBottom:`1px solid ${C.lineCol}`,position:"sticky",top:0,zIndex:100,boxShadow:"0 1px 14px rgba(26,43,60,.08)"}}>
        <div style={{maxWidth:740,margin:"0 auto",padding:"0 16px",display:"flex",alignItems:"center",height:54,gap:12}}>
          <div style={{display:"flex",alignItems:"center",gap:9}}>
            <div style={{width:34,height:34,borderRadius:9,background:C.navy,display:"flex",alignItems:"center",justifyContent:"center",fontSize:17}}>📊</div>
            <div>
              <div style={{fontSize:13,fontWeight:800,color:C.navy,fontFamily:FF.serif}}>joynity Growth Check</div>
              <div style={{fontSize:9,color:C.stone}}>成長発達チェックシステム</div>
            </div>
          </div>
          <div style={{display:"flex",alignItems:"center",gap:3,marginLeft:"auto"}}>
            {STEPS.map((s,i)=>(
              <div key={i} style={{display:"flex",alignItems:"center",gap:3}}>
                <button onClick={()=>setStep(i)} title={s.label} style={{width:28,height:28,borderRadius:"50%",border:"none",cursor:"pointer",background:i===step?C.navy:i<step?C.teal:C.lineCol,color:i<=step?C.white:C.stone,fontSize:i<step?11:10,fontWeight:700,display:"flex",alignItems:"center",justifyContent:"center",transition:"all .2s"}}>
                  {i<step?"✓":s.icon}
                </button>
                {i<5&&<div style={{width:8,height:2,borderRadius:1,background:i<step?C.teal:C.lineCol}}/>}
              </div>
            ))}
          </div>
        </div>
        <div style={{height:3,background:C.lineCol}}><div style={{width:`${(step/5)*100}%`,height:"100%",background:`linear-gradient(90deg,${C.teal},${C.navy})`,transition:"width .4s"}}/></div>
      </div>

      <div style={{maxWidth:740,margin:"0 auto",padding:"18px 14px 48px"}}>
        {step<5&&(
          <div className="no-print" style={{marginBottom:14,display:"flex",alignItems:"baseline",justifyContent:"space-between",flexWrap:"wrap",gap:8}}>
            <div style={{fontSize:19,fontWeight:900,color:C.navy,fontFamily:FF.serif}}>{STEPS[step].icon} {STEPS[step].label}</div>
            {step===0&&<div style={{display:"flex",gap:8,alignItems:"center"}}>
              <input type="file" accept=".csv" ref={intakeRef} onChange={loadCSV} style={{display:"none"}}/>
              <button onClick={()=>intakeRef.current?.click()} style={{padding:"6px 13px",borderRadius:8,border:`1.5px solid ${C.teal}`,background:C.tealLt,color:C.teal,fontSize:12,fontWeight:700,fontFamily:FF.sans,cursor:"pointer"}}>📥 事前CSV読込</button>
              {csvMsg&&<span style={{fontSize:12,color:C.teal}}>{csvMsg}</span>}
            </div>}
          </div>
        )}

        {/* STEP 0 */}
        {step===0&&(<>
          <Card>
            <ST color={C.teal}>基本情報</ST>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12,marginBottom:12}}>
              <FR label="氏名" tight>{inp("name",basic,sB,"例：山田 太郎")}</FR>
              <FR label="管理ID" tight>{inp("player_id",basic,sB,"GC-001")}</FR>
              <FR label="年齢" tight>{inp("age",basic,sB,"13","number")}</FR>
              <FR label="学年" tight>{inp("grade",basic,sB,"中学2年")}</FR>
              <FR label="競技・活動" tight>{inp("sport",basic,sB,"例：サッカー・水泳等")}</FR>
              <FR label="評価日" tight>{inp("eval_date",basic,sB,"","date")}</FR>
              <FR label="身長（cm）" tight>{inp("height",basic,sB,"160","number")}</FR>
              <FR label="体重（kg）" tight>{inp("weight",basic,sB,"50","number")}</FR>
            </div>
            <FR label="担当スタッフ" tight>{inp("trainer",basic,sB,"後藤")}</FR>
          </Card>
          <Card>
            <ST color={C.violet}>保護者が一番気になること</ST>
            <div style={{fontSize:12,color:C.stone,marginBottom:12}}>レポートの最初に個別のサポートロードマップとして表示されます（複数選択可）</div>
            <div style={{display:"flex",flexWrap:"wrap",gap:8}}>
              {CONCERN_OPTS.map(opt=>{
                const active=(basic.concerns||[]).includes(opt.id);
                return <button key={opt.id} onClick={()=>{const cur=basic.concerns||[];sB("concerns")(active?cur.filter(x=>x!==opt.id):[...cur,opt.id]);}} style={{padding:"8px 14px",borderRadius:24,border:`1.5px solid ${active?C.violet:C.lineCol}`,background:active?C.violetLt:C.cream,color:active?C.violet:C.stone,fontSize:13,fontWeight:active?700:400,fontFamily:FF.sans,cursor:"pointer",transition:"all .15s"}}>
                  {opt.icon} {opt.label}
                </button>;
              })}
            </div>
          </Card>
          <Card>
            <ST color={C.navy}>引き継ぎメモ</ST>
            <FR label="Joynity介入内容" tight>{ta("joynity_plan",basic,sB,"例：大腿前面リリース＋デッドバグ指導")}</FR>
            <FR label="次回医師に確認したい項目" tight>{ta("next_doctor_check",basic,sB,"例：右膝の成長板への負荷について確認")}</FR>
          </Card>
        </>)}

        {/* STEP 1 */}
        {step===1&&<Card>
          <ST color={C.coral}>症状の確認</ST>
          <FR label="気になる部位" hint="複数ある場合は複数を選んでください">
            <PG opts={["なし","膝前面","踵","腰","股関節","肩・肘","足首","その他"]} val={symptom.symptom_parts} onChange={sS("symptom_parts")} multi color={C.coral} bg={C.coralLt}/>
          </FR>
          {!(symptom.symptom_parts.length===1&&symptom.symptom_parts[0]==="なし")&&<>
            <FR label="症状の頻度"><PG opts={["月1回程度","週1回程度","週2〜3回","毎日"]} val={symptom.symptom_freq} onChange={sS("symptom_freq")} color={C.coral} bg={C.coralLt}/></FR>
            <FR label="症状が出やすいタイミング" hint="複数選択可"><PG opts={["なし","運動中","運動後","翌朝","ダッシュ時","ジャンプ時","切り返し時","長時間歩いた後","押すと痛い"]} val={symptom.symptom_timing} onChange={sS("symptom_timing")} multi color={C.amber} bg={C.amberLt}/></FR>
            <FR label="日常・活動への影響"><PG opts={["なし","少し気になるが活動可能","一部の動作を避けている","活動量を減らしている","休む必要がある"]} val={symptom.symptom_impact} onChange={sS("symptom_impact")} color={C.coral} bg={C.coralLt}/></FR>
            <FR label="現在の対応"><PG opts={["違和感があっても続けている","活動量を調整している","保護者やコーチに相談している","医療機関を受診している","どう対応すればよいかわからない"]} val={symptom.pain_response} onChange={sS("pain_response")} color={C.amber} bg={C.amberLt}/></FR>
          </>}
          <FR label="保護者が気になること" tight>{ta("parent_concern",symptom,sS,"例：最近膝が痛そうで心配")}</FR>
          <FR label="本人が気になること" tight>{ta("player_concern",symptom,sS,"例：ジャンプの踏み込みが怖い")}</FR>
        </Card>}

        {/* STEP 2 */}
        {step===2&&<>
          <div style={{background:C.blueLt,border:`1px solid ${C.blue}33`,borderRadius:10,padding:"10px 14px",marginBottom:14,fontSize:12,color:C.navy,lineHeight:1.6}}>
            💡 実施できない項目は <strong>「非実施」</strong> を選択してください。スコア計算から除外されます。
          </div>
          <Card>
            <ST color={C.blue}>1. 可動域（最大10pt）</ST>
            <FR label="胸椎回旋（床と肩峰間距離）">
              <PG opts={["OK（10cm未満）","NG（10cm以上）",NA_OPT]} val={ev.thoracic_ok_str} onChange={sE("thoracic_ok_str")} color={C.blue} bg={C.blueLt}/>
            </FR>
            <FR label="しゃがみ込み制限分類">
              <PG opts={withNA(["制限なし","足関節制限","股関節制限","足関節・股関節制限","関節協調性制限"])} val={ev.squat_limit} onChange={sE("squat_limit")} color={C.blue} bg={C.blueLt}/>
            </FR>
          </Card>
          <Card>
            <ST color={C.blue}>2. 柔軟性（最大10pt）</ST>
            <FR label="SLR">
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
                {[["slr_r","右(R)"],["slr_l","左(L)"]].map(([k,lb])=><div key={k}><div style={{fontSize:11,color:C.stone,marginBottom:5}}>{lb}</div><PG opts={withNA(["90度","反対側大腿〜膝蓋骨上縁以上","膝未満"])} val={ev[k]} onChange={sE(k)} color={C.blue} bg={C.blueLt} sm/></div>)}
              </div>
            </FR>
            <FR label="HBD 10cm未満OK">
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
                {[["hbd_r_ok","右(R)"],["hbd_l_ok","左(L)"]].map(([k,lb])=><div key={k}><div style={{fontSize:11,color:C.stone,marginBottom:5}}>{lb}</div>
                  <div style={{display:"flex",gap:8}}>
                    <Check label="OK" val={ev[k]===true} onChange={v=>sE(k)(v?true:null)}/>
                    <Check label="NG" val={ev[k]===false} onChange={v=>sE(k)(v?false:null)}/>
                    <Pill active={ev[k]===NA_OPT} color={C.stone} bg={C.sand} onClick={()=>sE(k)(ev[k]===NA_OPT?null:NA_OPT)} sm>非実施</Pill>
                  </div>
                </div>)}
              </div>
            </FR>
          </Card>
          <Card>
            <ST color={C.blue}>3. 体幹機能（最大15pt）</ST>
            <FR label="骨盤固定SLR">
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
                {[["pelvis_r","右(R)"],["pelvis_l","左(L)"]].map(([k,lb])=><div key={k}><div style={{fontSize:11,color:C.stone,marginBottom:5}}>{lb}</div><PG opts={["OK","NG",NA_OPT]} val={ev[k]} onChange={sE(k)} color={C.blue} bg={C.blueLt}/></div>)}
              </div>
            </FR>
            <FR label="Push-up"><PG opts={withNA(["額レベルでできる","鎖骨レベルでできる","できない"])} val={ev.pushup} onChange={sE("pushup")} color={C.blue} bg={C.blueLt}/></FR>
            <FR label="呼吸 呼気6秒"><PG opts={withNA(["呼気6秒できる","4秒以上6秒未満","できない"])} val={ev.breath} onChange={sE("breath")} color={C.blue} bg={C.blueLt}/></FR>
          </Card>
          <Card>
            <ST color={C.blue}>4. 協調運動（最大15pt）</ST>
            <FR label="スクワット"><PG opts={withNA(["できる","手が下がるができる","臀部が膝下の高さまで下がるが制限あり","できない"])} val={ev.squat_coord} onChange={sE("squat_coord")} color={C.blue} bg={C.blueLt}/></FR>
            <FR label="片脚屈伸 協調">
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
                {[["sls_r","右(R)"],["sls_l","左(L)"]].map(([k,lb])=><div key={k}><div style={{fontSize:11,color:C.stone,marginBottom:5}}>{lb}</div><PG opts={withNA(["できる","臀部が膝下まで下がる","片脚しゃがみ込み姿勢はできる","できない"])} val={ev[k]} onChange={sE(k)} color={C.blue} bg={C.blueLt} sm/></div>)}
              </div>
            </FR>
            <FR label="垂直跳び" hint="年齢別平均との比較で評価">
              <PG opts={withNA(["年齢平均以上","年齢平均","年齢平均未満"])} val={ev.vertical_jump} onChange={sE("vertical_jump")} color={C.blue} bg={C.blueLt}/>
            </FR>
          </Card>
          <Card>
            <ST color={C.blue}>5. 筋力（最大10pt）</ST>
            <FR label="片脚屈伸">
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
                {[["strength_r","右(R)"],["strength_l","左(L)"]].map(([k,lb])=><div key={k}><div style={{fontSize:11,color:C.stone,marginBottom:5}}>{lb}</div><PG opts={withNA(["できる","臀部が膝下まで下がる","片脚しゃがみ込み姿勢はできる","できない"])} val={ev[k]} onChange={sE(k)} color={C.blue} bg={C.blueLt} sm/></div>)}
              </div>
            </FR>
            <FR label="20cm段差起立">
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
                {[["step_r","右"],["step_l","左"]].map(([k,lb])=><div key={k}><div style={{fontSize:11,color:C.stone,marginBottom:5}}>{lb}</div><PG opts={["できる","できない",NA_OPT]} val={ev[k]} onChange={sE(k)} color={C.blue} bg={C.blueLt}/></div>)}
              </div>
            </FR>
          </Card>
          <Card>
            <ST color={C.blue}>6. バランス（最大10pt）</ST>
            <FR label="タンデム立位">
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
                {[["tandem_r","右前"],["tandem_l","左前"]].map(([k,lb])=><div key={k}><div style={{fontSize:11,color:C.stone,marginBottom:5}}>{lb}</div><PG opts={withNA(["閉眼20秒","開眼20秒","できない"])} val={ev[k]} onChange={sE(k)} color={C.blue} bg={C.blueLt}/></div>)}
              </div>
            </FR>
            <FR label="片脚立位" hint="手は腰・対側股関節90度以上">
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
                {[["slb_r","右軸"],["slb_l","左軸"]].map(([k,lb])=><div key={k}><div style={{fontSize:11,color:C.stone,marginBottom:5}}>{lb}</div><PG opts={withNA(["30秒完全にできる","骨盤後傾位でできる","足が下がるができる","15〜29秒良い姿勢でできる","15〜29秒、骨盤後傾または足が下がる","できない"])} val={ev[k]} onChange={sE(k)} color={C.blue} bg={C.blueLt} sm/></div>)}
              </div>
            </FR>
            <FR label="メモ" tight>{ta("staff_memo",ev,sE,"気になった動作・特記事項など")}</FR>
          </Card>
        </>}

        {/* STEP 3 */}
        {step===3&&<Card>
          <ST color={C.teal}>生活習慣の確認</ST>
          <div style={{background:C.blueLt,border:`1px solid ${C.blue}33`,borderRadius:10,padding:"10px 14px",marginBottom:16,fontSize:12,color:C.navy,lineHeight:1.6}}>
            💡 睡眠・栄養・水分補給は成長ホルモンの分泌・骨の成長・身体の回復に大切です。活動をしているお子様には特に重要な習慣です。
          </div>
          <FR label="平均睡眠時間" hint="目安：小学生9〜12時間 ／ 中高生8〜10時間（スポーツ実施者は+1〜2時間が理想）">
            <PG opts={["6時間未満","6〜7時間","7〜8時間","8〜9時間","9時間以上"]} val={habit.sleep} onChange={sH("sleep")}/>
          </FR>
          <FR label="活動後の補食（週あたり）" hint="活動後30分以内の炭水化物＋たんぱく質補給が目安">
            <PG opts={["週5回以上","週3〜4回","週1〜2回","月数回","なし"]} val={habit.snack} onChange={sH("snack")}/>
          </FR>
          <FR label="セルフケア・ストレッチ（週あたり）">
            <PG opts={["週5回以上","週3〜4回","週1〜2回","月数回","なし"]} val={habit.selfcare} onChange={sH("selfcare")}/>
          </FR>
          <FR label="水分補給（活動中）">
            <PG opts={["活動量に応じて意識して増やしている","活動中に定期的に飲む","活動中に数回飲む","喉が渇いた時だけ飲む","水分を持参していないことがある"]} val={habit.hydration} onChange={sH("hydration")}/>
          </FR>
          <FR label="自主的なトレーニング（週あたり）">
            <PG opts={["週5回以上","週3〜4回","週1〜2回","ほとんどない","活動が多く休養日が少ない"]} val={habit.self_training} onChange={sH("self_training")}/>
          </FR>
        </Card>}

        {/* STEP 4 */}
        {step===4&&<Card>
          <ST color={C.coral}>医師評価（上村先生）</ST>
          <div style={{background:C.blueLt,border:`1px solid ${C.blue}33`,borderRadius:10,padding:"10px 14px",marginBottom:16,fontSize:12,color:C.navy,lineHeight:1.6}}>
            💡 この評価は病変評価ではなく、<strong>成長成熟度評価</strong>です。成長ステージはエコー・成長曲線・年間成長速度・身体成熟を総合して推定します。
          </div>
          <FR label="成長タイプ"><PG opts={["標準型","早熟型","晩熟型","判定保留"]} val={doctor.growth_type} onChange={sD("growth_type")} color={C.coral} bg={C.coralLt}/></FR>
          <FR label="成長ステージ">
            <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
              {[{k:"pre",l:"Pre PHV",sub:"成長準備期"},{k:"peak",l:"Peak PHV",sub:"急成長期"},{k:"post",l:"Post PHV",sub:"成長安定期"},{k:"hold",l:"判定保留",sub:"確認中"}].map(s=>(
                <button key={s.k} onClick={()=>sD("stage")(s.k)} style={{flex:"1 0 auto",minWidth:90,padding:"10px 8px",borderRadius:10,border:`2px solid ${doctor.stage===s.k?C.coral:C.lineCol}`,background:doctor.stage===s.k?C.coralLt:C.cream,cursor:"pointer",textAlign:"center"}}>
                  <div style={{fontSize:12,fontWeight:800,color:doctor.stage===s.k?C.coral:C.navy,fontFamily:FF.serif}}>{s.l}</div>
                  <div style={{fontSize:10,color:C.stone}}>{s.sub}</div>
                </button>
              ))}
            </div>
          </FR>
          <FR label="医師からのメッセージ（保護者レポートに表示）" tight>{ta("doctor_note",doctor,sD,"例：今は成長の大切な時期です。体のサインを大切にしてください。")}</FR>
          <FR label="活動参加の目安">
            <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
              {[{k:"通常参加可能",mark:"○",col:C.teal},{k:"状況に応じて調整",mark:"△",col:C.amber},{k:"医師へ相談推奨",mark:"□",col:C.coral}].map(o=>(
                <button key={o.k} onClick={()=>sD("participation")(o.k)} style={{flex:"1 0 auto",minWidth:120,padding:"11px 10px",borderRadius:10,border:`2px solid ${doctor.participation===o.k?o.col:C.lineCol}`,background:doctor.participation===o.k?o.col+"18":C.cream,cursor:"pointer",textAlign:"center"}}>
                  <span style={{fontSize:16,fontWeight:900,color:doctor.participation===o.k?o.col:C.stone,marginRight:6}}>{o.mark}</span>
                  <span style={{fontSize:13,fontWeight:700,color:doctor.participation===o.k?o.col:C.navy}}>{o.k}</span>
                </button>
              ))}
            </div>
          </FR>
        </Card>}

        {/* STEP 5: Report */}
        {step===5&&<>
          <div className="no-print" style={{display:"flex",gap:8,marginBottom:14,flexWrap:"wrap"}}>
            {[{l:"成長適応度",v:`${computed.gas}%`,c:computed.gas>=70?C.teal:computed.gas>=50?C.amber:C.coral},{l:"身体機能",v:`${computed.bodyNorm}%`,c:C.teal},{l:"生活習慣",v:`${computed.habitScore}%`,c:C.amber},{l:"現在の状態",v:{safe:"🟢 順調",watch:"🟡 サポート期",caution:"🟠 重点サポート"}[computed.status]||"—",c:{safe:C.teal,watch:C.amber,caution:"#C97D10"}[computed.status]||C.stone}].map(({l,v,c},i)=>(
              <div key={i} style={{flex:1,minWidth:70,background:C.white,borderRadius:12,padding:"10px 12px",textAlign:"center",boxShadow:"0 2px 12px rgba(26,43,60,.06)",border:`1px solid ${C.lineCol}`}}>
                <div style={{fontSize:9,color:C.stone,marginBottom:3}}>{l}</div>
                <div style={{fontSize:15,fontWeight:900,color:c,fontFamily:FF.serif}}>{v}</div>
              </div>
            ))}
          </div>
          <div className="no-print" style={{display:"flex",gap:0,marginBottom:14,background:C.white,borderRadius:14,padding:4,boxShadow:"0 2px 14px rgba(26,43,60,.08)",border:`1px solid ${C.lineCol}`}}>
            {["📄 保護者","🧒 本人","🏅 コーチ","📊 詳細","🔬 スタッフ"].map((lb,i)=>(
              <button key={i} onClick={()=>setRepTab(i)} style={{flex:1,padding:"9px 4px",borderRadius:10,border:"none",background:repTab===i?C.navy:"transparent",color:repTab===i?C.white:C.stone,fontWeight:repTab===i?800:400,fontSize:11,cursor:"pointer",transition:"all .2s",fontFamily:FF.sans}}>
                {lb}
              </button>
            ))}
          </div>
          <div id="print-area">
            {repTab===0&&<ParentReport all={all}/>}
            {repTab===1&&<AthleteReport all={all}/>}
            {repTab===2&&<CoachReport all={all}/>}
            {repTab===3&&<DetailReport all={all}/>}
            {repTab===4&&<StaffReport all={all}/>}
          </div>
          <div className="no-print" style={{display:"flex",gap:10,marginTop:18,justifyContent:"flex-end",flexWrap:"wrap"}}>
            <button onClick={handlePrint} style={{padding:"10px 20px",borderRadius:10,border:"none",background:`linear-gradient(135deg,${C.coral},#B84030)`,color:C.white,fontSize:13,fontWeight:800,cursor:"pointer",fontFamily:FF.sans,boxShadow:`0 4px 14px ${C.coral}44`}}>🖨 PDF出力（このタブを印刷）</button>
            <button onClick={handleExport} style={{padding:"10px 18px",borderRadius:10,border:`1.5px solid ${C.teal}`,background:C.tealLt,color:C.teal,fontSize:13,fontWeight:700,cursor:"pointer",fontFamily:FF.sans}}>📥 CSVで保存</button>
            <button onClick={()=>setStep(0)} style={{padding:"10px 18px",borderRadius:10,border:`1.5px solid ${C.lineCol}`,background:C.white,color:C.navy,fontSize:13,fontWeight:600,cursor:"pointer",fontFamily:FF.sans}}>↺ 新規評価</button>
          </div>
        </>}

        {/* Nav */}
        <div className="no-print" style={{display:"flex",justifyContent:"space-between",marginTop:18,gap:12}}>
          <button onClick={()=>setStep(Math.max(0,step-1))} disabled={step===0} style={{padding:"10px 20px",borderRadius:12,border:`1.5px solid ${C.lineCol}`,background:step===0?C.sand:C.white,color:step===0?C.stone:C.navy,fontSize:13,fontWeight:600,cursor:step===0?"default":"pointer",fontFamily:FF.sans}}>← 戻る</button>
          {step<5&&<button onClick={()=>setStep(step+1)} style={{padding:"10px 28px",borderRadius:12,border:"none",background:`linear-gradient(135deg,${C.teal},${C.tealDim})`,color:C.white,fontSize:13,fontWeight:800,cursor:"pointer",fontFamily:FF.sans,boxShadow:`0 4px 14px ${C.teal}44`}}>
            {step===4?"レポートを確認 →":"次へ →"}
          </button>}
        </div>
      </div>
    </div>
  );
}
